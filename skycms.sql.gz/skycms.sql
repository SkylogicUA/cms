-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 14, 2012 at 10:49 AM
-- Server version: 5.1.40
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `skycms`
--

-- --------------------------------------------------------

--
-- Table structure for table `bascket`
--

CREATE TABLE IF NOT EXISTS `bascket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `product_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(64) NOT NULL,
  `price` float(12,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `bascket`
--

INSERT INTO `bascket` (`id`, `date`, `product_id`, `amount`, `user_id`, `session_id`, `price`) VALUES
(22, '2012-08-01 16:49:13', 10, 8, 0, '76d2b594052e31700972f1d6c5efcc4e', 65.00),
(23, '2012-08-01 16:49:42', 9, 2, 0, '76d2b594052e31700972f1d6c5efcc4e', 70.00),
(24, '2012-08-01 18:02:39', 14, 3, 0, '76d2b594052e31700972f1d6c5efcc4e', 80.00),
(25, '2012-08-15 16:32:37', 10, 1, 0, '6d7f35c30daf441a7f220e8e567c9325', 65.00),
(26, '2012-08-15 16:32:42', 14, 1, 0, '6d7f35c30daf441a7f220e8e567c9325', 80.00),
(27, '2012-08-16 12:36:49', 9, 1, 0, 'b88eae5ab8309c8291de983fcc851f75', 70.00),
(30, '2012-09-06 17:47:20', 14, 2, 0, '62490aeaf2c984dd41ed32bc54666ca0', 80.00),
(42, '2012-09-12 17:27:53', 10, 1, 0, '524eb6105c76deb562845d45d504e227', 65.00);

-- --------------------------------------------------------

--
-- Table structure for table `brend`
--

CREATE TABLE IF NOT EXISTS `brend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` enum('0','1') DEFAULT '0' COMMENT '1-��������/0-�� ��������',
  `sort` int(11) DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='����������: �������������' AUTO_INCREMENT=10 ;

--
-- Dumping data for table `brend`
--

INSERT INTO `brend` (`id`, `active`, `sort`, `url`) VALUES
(8, '1', 0, 'addidas'),
(9, '1', 0, 'nike');

-- --------------------------------------------------------

--
-- Table structure for table `catalog`
--

CREATE TABLE IF NOT EXISTS `catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `catalog`
--

INSERT INTO `catalog` (`id`, `sub`, `sort`, `active`, `url`) VALUES
(2, NULL, 3, '1', 'library'),
(3, NULL, 2, '1', 'service'),
(9, NULL, 1, '1', 'catalog'),
(10, 9, 1, '1', 'igrushki'),
(11, 9, 2, '1', 'ukrasheniya'),
(12, 9, 3, '1', 'dekor-interera'),
(13, 9, 5, '1', 'upakovka'),
(15, 9, 4, '1', 'otkritki'),
(16, 10, 0, '1', 'kote'),
(17, 10, 0, '1', 'zaychiki');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(2) DEFAULT 'ru',
  `author` varchar(128) DEFAULT NULL,
  `photo` varchar(128) NOT NULL,
  `text` text,
  `date` datetime DEFAULT '0000-00-00 00:00:00',
  `content_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(128) DEFAULT NULL,
  `session_id` varchar(255) NOT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `language`, `author`, `photo`, `text`, `date`, `content_id`, `type`, `session_id`, `active`) VALUES
(5, 'ru', 'Саша Ким', '', 'asdasdasd', '2012-07-07 18:01:58', 46, 'pages', '57ef03290ee1449c34a6083073910379', '1'),
(6, 'ru', 'Саша Ким', 'http://cs11234.userapi.com/u8657787/e_0f15b748.jpg', 'asdasd', '2012-07-07 18:02:25', 46, 'pages', '57ef03290ee1449c34a6083073910379', '1'),
(7, 'ru', 'Саша Ким', 'http://cs11234.userapi.com/u8657787/e_0f15b748.jpg', 'asdasdad', '2012-07-07 18:02:57', 46, 'pages', '57ef03290ee1449c34a6083073910379', '1');

-- --------------------------------------------------------

--
-- Table structure for table `const`
--

CREATE TABLE IF NOT EXISTS `const` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `value` text,
  `comment` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='��������� �����' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `const`
--

INSERT INTO `const` (`id`, `name`, `value`, `comment`) VALUES
(8, 'email', 'www_alex@list.ru', 'Контактный E-mail'),
(9, 'sitename', 'Студия подарков', 'Название сайта'),
(10, 'google', '', 'Google Analitics'),
(12, 'col_product', '10', 'Кол-во товаров в каталоге'),
(13, 'limit_news_block', '3', 'Кол-во новостей слева');

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE IF NOT EXISTS `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `icon` varchar(5) NOT NULL,
  `rate` float(12,4) NOT NULL,
  `name` varchar(32) NOT NULL,
  `position` int(1) NOT NULL,
  `base` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `icon`, `rate`, `name`, `position`, `base`) VALUES
(1, 'грн.', 0.0000, 'Гривна', 1, '1'),
(2, '€', 10.0154, 'Евро', 0, '0'),
(3, '$', 8.0900, 'Доллар', 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE IF NOT EXISTS `delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` float(12,2) NOT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`id`, `price`, `active`, `sort`) VALUES
(5, 150.00, '1', 0),
(6, 0.00, '1', 0),
(7, 180.00, '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `email`
--


-- --------------------------------------------------------

--
-- Table structure for table `en_brend`
--

CREATE TABLE IF NOT EXISTS `en_brend` (
  `brend_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `body` longtext NOT NULL,
  `title` varchar(256) NOT NULL,
  `keywords` varchar(256) NOT NULL,
  `description` varchar(256) NOT NULL,
  KEY `brand_id` (`brend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_brend`
--

INSERT INTO `en_brend` (`brend_id`, `name`, `body`, `title`, `keywords`, `description`) VALUES
(8, 'Addidas', '', '', '', ''),
(9, 'Nike', '&lt;p&gt;jjjjjjj&lt;/p&gt;', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `en_catalog`
--

CREATE TABLE IF NOT EXISTS `en_catalog` (
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_catalog`
--

INSERT INTO `en_catalog` (`cat_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(2, 'Литература', 'ф', 'фф', 'ввв', '&lt;p&gt;описени&lt;/p&gt;'),
(3, 'Услуги', 'в', 'ввввввввввв', 'ввввввввввввввв', '&lt;p&gt;ываыва&lt;/p&gt;'),
(9, 'Каталог товаров', '', '', '', ''),
(10, 'Игрушки', '', '', '', ''),
(11, 'Украшения', '', '', '', ''),
(12, 'Декор интерьера', '', '', '', ''),
(13, 'Упаковка', '', '', '', ''),
(15, 'Открытки', '', '', '', ''),
(16, 'Котэ', '', '', '', ''),
(17, 'Зайчики', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `en_delivery`
--

CREATE TABLE IF NOT EXISTS `en_delivery` (
  `delivery_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `delivery_id` (`delivery_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_delivery`
--

INSERT INTO `en_delivery` (`delivery_id`, `name`) VALUES
(5, 'Courier'),
(6, 'Pickup'),
(7, 'New mail');

-- --------------------------------------------------------

--
-- Table structure for table `en_info_blocks`
--

CREATE TABLE IF NOT EXISTS `en_info_blocks` (
  `info_id` int(11) DEFAULT NULL COMMENT '��� �����',
  `name` varchar(64) DEFAULT NULL COMMENT '������������',
  `body` text,
  KEY `pages_id` (`info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU: ���� ����� ';

--
-- Dumping data for table `en_info_blocks`
--

INSERT INTO `en_info_blocks` (`info_id`, `name`, `body`) VALUES
(1, 'Верхние контакты', '&lt;p&gt;&#040;066&#041; 314 15 23&lt;br /&gt; &#040;066&#041; 314 15 23&lt;/p&gt;'),
(3, 'Рекомендации', '&lt;h3&gt;Рекомендации&lt;/h3&gt;\r\n&lt;p&gt;Как правильно измерять артериальное давление&lt;br /&gt;Точность полученных результатов, гарантия правильной диагностики гипертонии зависят от соблюдения некоторых правил. Для определения артериального давления имеют значение положение пациента, сопутствующие обстоятельства, оснащение и владение техникой измерения.&lt;/p&gt;\r\n&lt;p&gt;Как правильно принимать таблетки&lt;br /&gt;Если таблетка имеет овальную форму и покрыта оболочкой, ее следует глотать не разжевывая &#040;это же относится к порошкам в капсулах&#041;. кардиограф Остальные таблетки и порошки перед приемом внутрь желательно измельчить и запить жидкостью.&lt;/p&gt;\r\n&lt;p&gt;Как правильно измерять артериальное давление&lt;br /&gt;Точность полученных результатов, гарантия правильной диагностики гипертонии зависят от соблюдения некоторых правил. Для определения артериального давления имеют значение положение пациента, сопутствующие обстоятельства, оснащение и владение техникой измерения.&lt;/p&gt;'),
(4, 'Бонус', '&lt;p&gt;&lt;a href=&quot;/discount&quot;&gt;&lt;img src=&quot;/files/storage/images/ban4.png&quot; alt=&quot;&quot; /&gt;&lt;/a&gt;&lt;/p&gt;'),
(5, 'Бренды', '&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Бренды&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;img src=&quot;/files/storage/images/ban1.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt;&lt;img src=&quot;/files/storage/images/ban2.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt;&lt;img src=&quot;/files/storage/images/ban3.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;'),
(6, 'Баннер на главной &#040;верхний&#041;', '&lt;p&gt;&lt;img src=&quot;/files/storage/ban.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;'),
(7, 'Баннер на главной &#040;нижний&#041;', '&lt;p&gt;&lt;img src=&quot;/files/storage/images/banner.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `en_menu`
--

CREATE TABLE IF NOT EXISTS `en_menu` (
  `menu_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `menu_id` (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_menu`
--

INSERT INTO `en_menu` (`menu_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(78, 'Главное менюggg', '', '', '', ''),
(79, 'photo', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `en_meta_data`
--

CREATE TABLE IF NOT EXISTS `en_meta_data` (
  `meta_id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `body` longtext,
  `keywords` text,
  `description` text,
  KEY `meta_id` (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU:SEO оптимизация';

--
-- Dumping data for table `en_meta_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `en_news`
--

CREATE TABLE IF NOT EXISTS `en_news` (
  `news_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body_m` varchar(256) NOT NULL,
  `body` longtext,
  KEY `news_id` (`news_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_news`
--

INSERT INTO `en_news` (`news_id`, `name`, `title`, `keywords`, `description`, `body_m`, `body`) VALUES
(4, 'Новостной заголовок 2', '', '', '', 'Создание одного приверженного покупателя все же амбивалентно. Привлечение всей же аудитории стабилизирует.', '&lt;p&gt;Тонометры - приборы которые измеряют давление крови в организме человека.&lt;/p&gt;'),
(5, 'Новостной заголовок', '', '', '', 'Создание одного приверженного покупателя все же амбивалентно. Привлечение всей же аудитории стабилизирует.', '');

-- --------------------------------------------------------

--
-- Table structure for table `en_pages`
--

CREATE TABLE IF NOT EXISTS `en_pages` (
  `pages_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `pages_id` (`pages_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_pages`
--

INSERT INTO `en_pages` (`pages_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(27, 'Home', '', '', '', ''),
(39, 'Открытие авто', '', '', '', 'кккк'),
(41, 'Открытие сейфов', '', '', '', ''),
(42, 'Изготовление ключей', '', '', '', ''),
(43, 'Замена и установка замков', '', '', '', ''),
(44, 'Ремонт и сервис замков', '', '', '', ''),
(45, 'Описание скидки', '', '', '', ''),
(46, 'Главное менюk', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `en_params`
--

CREATE TABLE IF NOT EXISTS `en_params` (
  `params_id` int(11) DEFAULT NULL COMMENT 'Код группы категории',
  `name` varchar(64) DEFAULT NULL COMMENT 'Наименование категории номенклатуры',
  `info` text,
  KEY `params_id` (`params_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU справочник: Свойства продукции';

--
-- Dumping data for table `en_params`
--

INSERT INTO `en_params` (`params_id`, `name`, `info`) VALUES
(1, 'Мощность', NULL),
(2, 'Тип нагрева', NULL),
(3, '24кВт', NULL),
(4, '21-32кВт', NULL),
(5, 'отопление&#043;ГВС', NULL),
(6, 'отопление', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `en_payment`
--

CREATE TABLE IF NOT EXISTS `en_payment` (
  `payment_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `payment_id` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_payment`
--

INSERT INTO `en_payment` (`payment_id`, `name`) VALUES
(1, 'Новости сайта'),
(2, 'Privat Bank');

-- --------------------------------------------------------

--
-- Table structure for table `en_photo`
--

CREATE TABLE IF NOT EXISTS `en_photo` (
  `photo_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_photo`
--

INSERT INTO `en_photo` (`photo_id`, `name`) VALUES
(1, 'Lexus_LF-A_Sports,_Car_Concept,_2007'),
(3, '153746_272837'),
(4, 'Aston_Martin_AMV10_sports_cars_wallpapers'),
(5, 'Lexus_LF-A_Sports,_Car_Concept,_2007'),
(6, 'sports car wallpaper-5'),
(7, '153746_272837');

-- --------------------------------------------------------

--
-- Table structure for table `en_photos`
--

CREATE TABLE IF NOT EXISTS `en_photos` (
  `photos_id` int(11) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `body_m` varchar(255) DEFAULT NULL,
  `body` text,
  `title` varchar(128) DEFAULT NULL,
  `keywords` text,
  `description` text,
  KEY `photos_id` (`photos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_photos`
--

INSERT INTO `en_photos` (`photos_id`, `name`, `body_m`, `body`, `title`, `keywords`, `description`) VALUES
(1, 'Albom 1', NULL, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `en_product`
--

CREATE TABLE IF NOT EXISTS `en_product` (
  `product_id` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL,
  `body_m` longtext,
  `body` longtext,
  `title` varchar(128) DEFAULT NULL,
  `keywords` text,
  `description` text,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_product`
--

INSERT INTO `en_product` (`product_id`, `name`, `body_m`, `body`, `title`, `keywords`, `description`) VALUES
(9, 'Баварская', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '&lt;p&gt;Глюкометр&nbsp; Контур ТС &#040;CONTOUR TS&#041; требует всего 0,6 мкл крови и позволяет получить точные результаты уже через 8 секунд. Существует возможность взятия проб крови из разных мест &mdash; кончика пальца, ладони или предплечья.&lt;/p&gt;', '', '', ''),
(10, 'Чикен Ранч', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '', '', ''),
(15, 'Главное меню', '', '', '', '', ''),
(16, 'Фильтры товаров', '', '', '', '', ''),
(17, 'Юрий', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `en_product_photo`
--

CREATE TABLE IF NOT EXISTS `en_product_photo` (
  `photo_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `photo_id` (`photo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_product_photo`
--

INSERT INTO `en_product_photo` (`photo_id`, `name`) VALUES
(9, '153746_272837'),
(10, 'Aston_Martin_AMV10_sports_cars_wallpapers'),
(11, 'Lexus_LF-A_Sports,_Car_Concept,_2007'),
(12, 'sports car wallpaper-5'),
(13, 'sdf'),
(14, 'sdfsdf'),
(15, 'fffffffffff'),
(16, '1261_b'),
(17, '153746_272837'),
(18, 'Aston_Martin_AMV10_sports_cars_wallpapers'),
(19, 'Lexus_LF-A_Sports,_Car_Concept,_2007');

-- --------------------------------------------------------

--
-- Table structure for table `en_product_status`
--

CREATE TABLE IF NOT EXISTS `en_product_status` (
  `product_status_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `product_status_id` (`product_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_product_status`
--

INSERT INTO `en_product_status` (`product_status_id`, `name`) VALUES
(2, 'Юрий'),
(3, ''),
(4, 'Discount'),
(5, 'Hot offers'),
(6, 'Novetly');

-- --------------------------------------------------------

--
-- Table structure for table `en_slider`
--

CREATE TABLE IF NOT EXISTS `en_slider` (
  `slider_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `slider_id` (`slider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_slider`
--

INSERT INTO `en_slider` (`slider_id`, `name`) VALUES
(3, 'Новости сайта');

-- --------------------------------------------------------

--
-- Table structure for table `en_translate`
--

CREATE TABLE IF NOT EXISTS `en_translate` (
  `translate_id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text,
  PRIMARY KEY (`translate_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='TEXT RU: ������� ��������' AUTO_INCREMENT=232 ;

--
-- Dumping data for table `en_translate`
--

INSERT INTO `en_translate` (`translate_id`, `value`) VALUES
(1, 'Site development'),
(3, 'All rights reserved © 2012'),
(4, 'News'),
(7, 'Feedback'),
(8, 'Name'),
(9, 'City'),
(10, 'Phone'),
(11, 'Required fields'),
(12, 'Send'),
(68, 'You search'),
(70, 'Archive lessons'),
(72, 'Not founded'),
(82, 'Surname'),
(83, 'Name'),
(84, 'Address'),
(85, 'Phone'),
(86, 'Authorization'),
(106, 'The fields with * required'),
(108, 'Wrong email'),
(137, 'More'),
(155, 'E-mail'),
(156, 'Message'),
(157, 'Articles archive'),
(158, 'All news'),
(159, 'Last news'),
(165, 'Sky cms'),
(167, 'Last comments'),
(168, 'Information materials'),
(169, 'Ask a question'),
(170, 'Registration'),
(171, 'After checking your comment will be added'),
(172, 'Video Archive'),
(173, 'Comments'),
(174, 'Data saved successfully'),
(175, 'Registration for this manager'),
(176, 'You have successfully registered'),
(177, 'Invalid confirmation code'),
(178, 'This email is registered!'),
(179, 'Message sent!'),
(180, 'Next'),
(181, 'Order'),
(182, 'Search'),
(183, 'Checkout'),
(184, 'Description'),
(185, 'Params'),
(186, 'Catalog'),
(188, 'All'),
(190, 'Wrong phone'),
(191, 'Enter'),
(193, 'Password'),
(194, 'E-mail is not registered'),
(195, 'Thank you for logging'),
(196, 'Save'),
(197, 'My data'),
(198, 'My orders'),
(199, 'New passsword'),
(200, 'Old password'),
(201, 'Post index'),
(202, 'Cart is empty'),
(203, 'Your comments'),
(204, 'Logout'),
(209, 'Home'),
(210, 'E-mail has been added to the database!'),
(211, 'Subscription'),
(212, 'Subscribe'),
(213, 'Method of delivery'),
(214, 'Means of payment'),
(216, 'Brands'),
(217, 'Article'),
(218, 'All article'),
(219, 'Last article'),
(220, 'Gallery'),
(221, 'Name'),
(222, 'Delete'),
(223, 'Sum'),
(224, 'Amount'),
(225, 'Price'),
(226, 'Total'),
(227, 'See also'),
(228, 'Payable'),
(229, 'In cart'),
(231, '&lt;b&gt;Thank you for your order! &lt;/b&gt; &lt;br /&gt; Soon manager will contact you at the indicated E-mail!');

-- --------------------------------------------------------

--
-- Table structure for table `en_video`
--

CREATE TABLE IF NOT EXISTS `en_video` (
  `video_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  KEY `video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `en_video`
--


-- --------------------------------------------------------

--
-- Table structure for table `include_cod`
--

CREATE TABLE IF NOT EXISTS `include_cod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `value` text,
  `coment` text,
  `urln` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='��� ��� ������� �� ��������(�������� �������)' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `include_cod`
--


-- --------------------------------------------------------

--
-- Table structure for table `info_blocks`
--

CREATE TABLE IF NOT EXISTS `info_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0' COMMENT '1-��������/0-�� ��������',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='���� ����� �� �����' AUTO_INCREMENT=8 ;

--
-- Dumping data for table `info_blocks`
--

INSERT INTO `info_blocks` (`id`, `sort`, `active`) VALUES
(1, 1, '0'),
(3, 3, '0'),
(4, 2, '0'),
(5, 4, '0'),
(6, 5, '0'),
(7, 6, '0');

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domen` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(20) DEFAULT NULL,
  `comment` varchar(128) DEFAULT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domen` (`domen`),
  UNIQUE KEY `language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='���������� ������' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`id`, `domen`, `language`, `comment`, `sort`) VALUES
(2, '1', 'ru', 'Russian', 2),
(3, '3', 'en', 'English', 1);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  `form` enum('0','1','2') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`),
  KEY `sub` (`sub`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=80 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `sub`, `sort`, `active`, `url`, `form`) VALUES
(78, NULL, 1, '1', 'glavnoe-men-', '0'),
(79, NULL, 3, '1', 'photo', '0');

-- --------------------------------------------------------

--
-- Table structure for table `menu_admin`
--

CREATE TABLE IF NOT EXISTS `menu_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `menu_admin`
--

INSERT INTO `menu_admin` (`id`, `name`) VALUES
(1, 'Веб-сайт'),
(3, 'Пользователи'),
(2, 'Магазин'),
(4, 'Заказы'),
(5, 'Настройки'),
(6, 'Администрирование');

-- --------------------------------------------------------

--
-- Table structure for table `meta_data`
--

CREATE TABLE IF NOT EXISTS `meta_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(128) DEFAULT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU:SEO оптимизация' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `meta_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `moderators`
--

CREATE TABLE IF NOT EXISTS `moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(150) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `type_moderator` int(11) DEFAULT '0',
  `name` varchar(128) NOT NULL,
  `surname` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `phone` varchar(128) NOT NULL,
  `skype` varchar(128) NOT NULL,
  `city` varchar(128) NOT NULL,
  `text` text NOT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type_moderator` (`type_moderator`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `moderators`
--

INSERT INTO `moderators` (`id`, `login`, `password`, `type_moderator`, `name`, `surname`, `email`, `phone`, `skype`, `city`, `text`, `active`) VALUES
(1, 'admin', 'fc1d8d8c7f52dc8a94527a27fca15bf5', 1, '', '', '', '', '', '', '', '1'),
(3, 'admin2', 'fc1d8d8c7f52dc8a94527a27fca15bf5', 2, 'Юрий', 'Шкваренко', 'alexddd-kim@rambler.ru', '&#043;380635338366', 'g-xx-s', 'Ильичевскw', 'asdasd', '1');

-- --------------------------------------------------------

--
-- Table structure for table `moderators_auth`
--

CREATE TABLE IF NOT EXISTS `moderators_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `moder_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_agent` varchar(128) NOT NULL,
  `referer` varchar(256) NOT NULL,
  `ip` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `moderators_auth`
--

INSERT INTO `moderators_auth` (`id`, `moder_id`, `time`, `user_agent`, `referer`, `ip`) VALUES
(1, 1, '2012-03-13 11:45:08', 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/1', 'http://skycms/admin', '127.0.0.1'),
(2, 1, '2012-03-13 11:45:34', 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2', 'http://skycms/admin', '127.0.0.1'),
(3, 1, '2012-03-13 11:46:10', 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2', 'http://skycms/admin', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `moderators_permission`
--

CREATE TABLE IF NOT EXISTS `moderators_permission` (
  `moderators_type_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `permission` enum('000','100','200','300','400','500','600','700','800') NOT NULL COMMENT '''000''-off; ''100''-read; ''200''-read/edit; ''300''-read/del; ''400''-read/add; ''500''-read/edit/del; ''600''-read/edit/add; ''700''-read/del/add; ''800''-read/edit/del/add;',
  KEY `moderators_type_id` (`moderators_type_id`),
  KEY `moderators_type_id_2` (`moderators_type_id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `moderators_permission`
--

INSERT INTO `moderators_permission` (`moderators_type_id`, `module_id`, `permission`) VALUES
(1, 9, '800'),
(1, 59, '800'),
(2, 59, '800'),
(3, 59, '000'),
(1, 57, '800'),
(2, 57, '800'),
(3, 57, '800'),
(1, 2, '800'),
(2, 2, '800'),
(3, 2, '800'),
(1, 63, '800'),
(2, 63, '600'),
(3, 63, '200'),
(1, 61, '800'),
(2, 61, '800'),
(3, 61, '800'),
(1, 60, '800'),
(2, 60, '800'),
(3, 60, '000'),
(1, 67, '800'),
(2, 67, '800'),
(3, 67, '800'),
(1, 76, '800'),
(2, 76, '800'),
(3, 76, '800'),
(1, 79, '800'),
(2, 79, '800'),
(3, 79, '800'),
(1, 80, '800'),
(2, 80, '800'),
(3, 80, '800'),
(1, 87, '800'),
(2, 87, '800'),
(3, 87, '800'),
(1, 89, '800'),
(2, 89, '800'),
(3, 89, '800'),
(1, 100, '800'),
(2, 100, '800'),
(3, 100, '800'),
(1, 101, '800'),
(2, 101, '800'),
(3, 101, '800'),
(2, 9, '000'),
(1, 102, '800'),
(2, 102, '800'),
(3, 102, '800'),
(1, 104, '800'),
(2, 104, '800'),
(3, 104, '800'),
(1, 105, '800'),
(2, 105, '800'),
(3, 105, '800'),
(1, 106, '800'),
(2, 106, '800'),
(3, 106, '800'),
(1, 107, '800'),
(2, 107, '800'),
(3, 107, '800'),
(1, 109, '800'),
(2, 109, '800'),
(3, 109, '800'),
(1, 110, '800'),
(2, 110, '800'),
(3, 110, '800'),
(1, 113, '800'),
(2, 113, '800'),
(3, 113, '800'),
(1, 115, '800'),
(2, 115, '800'),
(3, 115, '800'),
(1, 116, '800'),
(2, 116, '600'),
(3, 116, '000'),
(1, 117, '800'),
(2, 117, '000'),
(3, 117, '000'),
(3, 9, '000');

-- --------------------------------------------------------

--
-- Table structure for table `moderators_type`
--

CREATE TABLE IF NOT EXISTS `moderators_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `moderators_type`
--

INSERT INTO `moderators_type` (`id`, `comment`) VALUES
(1, 'Супер администратор'),
(2, 'Администратор'),
(3, 'Модератор');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(1) NOT NULL DEFAULT '1',
  `name` varchar(128) DEFAULT NULL,
  `controller` varchar(128) DEFAULT NULL,
  `tables` varchar(512) NOT NULL,
  `comment` varchar(256) DEFAULT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=118 ;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`id`, `sub`, `name`, `controller`, `tables`, `comment`, `sort`) VALUES
(2, 1, 'Содержимое', 'pages', 'ru_pages,pages', 'Создать и опубликовать страницы, формы, опросы и ссылки.', 2),
(9, 6, 'Модули', 'modules', '', 'Модули', 26),
(57, 1, '﻿Главное меню', 'menu', 'ru_menu,menu', 'Редактирование главного меню\r\n', 1),
(59, 6, 'Группы модератров', 'moderatorstype', 'moderators_type', '', 25),
(60, 6, 'Модераторы', 'moderators', 'moderators', '', 24),
(61, 5, 'Настройки', 'config', 'const', '', 22),
(63, 1, 'Информационные блоки', 'info', 'ru_info,info', 'Информационные блоки', 3),
(67, 5, 'Переводы', 'translate', '', '', 21),
(76, 2, '﻿Каталог', 'catalog', 'ru_catalog,catalog', 'Просмотреть категории, в которые сгруппированы товары в Вашем магазине.\r\n', 11),
(79, 1, '﻿Новости сайта', 'news', 'ru_news,news', 'Редактировать новости, которые показываются в секции &quot;Новости сайта&quot; на витрине магазина.\r\n', 4),
(80, 1, '﻿Слайдер', 'slider', 'slider', 'Слайдер на главной странице.\r\n', 8),
(87, 3, '﻿Пользователи', 'users', 'users,user_status', 'Редактировать учетные записи пользователей, зарегистрированных в Вашем магазине.\r\n', 19),
(89, 1, '﻿Рассылки', 'mailer', 'email', 'База почтовых ящиков\r\n', 10),
(100, 2, '﻿Заказы', 'orders', 'orders_product,orders', 'Просмотреть, оформить и распечатать счет-фактуру для заказов, сделанных в Вашем магазине.\r\n', 14),
(101, 2, '﻿﻿Товары', 'product', 'ru_product,ru_product_photo,product_photo,product_status_set,product_catalog,product_status,product', 'Просмотреть, добавить и редактировать товары, которые показываются посетителям Вашего магазина.\r\n', 12),
(102, 6, '﻿Валюта', 'currency', 'currency', 'Курс валюты\r\n', 23),
(104, 2, '﻿Способ доставки', 'delivery', 'delivery', 'Способ доставки\r\n', 18),
(105, 2, '﻿Способ оплаты', 'payment', 'payment', 'Способ оплаты\r\n', 16),
(106, 2, '﻿Фильтры товаров', 'params', 'ru_params,params_product,params', 'Фильтры товаров показываются на витрине магазина и позволяют покупателям легко находить нужный товар.\r\n', 13),
(107, 1, '﻿Комментарии и отзывы', 'comments', 'comments,comments_type', 'Комментарии и отзывы пользователей.\r\n', 9),
(109, 1, '﻿Фотогалерея', 'photos', 'ru_photo,photo,ru_photos,photos', 'Фотогалерея с разделами\r\n', 5),
(110, 1, '﻿Видео', 'video', 'ru_video,video', 'Виодегалерея\r\n', 7),
(113, 5, '﻿Мета-данные', 'meta', 'ru_meta_data,meta_data', 'Мета-данные\r\n', 20),
(115, 2, 'Бренды', 'brend', 'brend', '', 15),
(116, 2, 'Статусы товаров', 'status', 'product_status', '', 17),
(117, 6, 'Языки', 'language', 'language', 'Языки\r\n', 0);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  `date` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `sort`, `active`, `url`, `date`) VALUES
(4, 0, '1', 'novostnoy-zagolovok-2', '2012-06-27 11:44:38'),
(5, 0, '1', 'novostnoy-zagolovok', '2012-06-27 12:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_add` datetime DEFAULT '0000-00-00 00:00:00',
  `date_edit` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sum` float(12,2) DEFAULT NULL,
  `discount` int(11) NOT NULL,
  `comment` text,
  `username` varchar(128) NOT NULL,
  `post_index` varchar(256) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `country` varchar(256) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `delivery` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `orders`
--


-- --------------------------------------------------------

--
-- Table structure for table `orders_product`
--

CREATE TABLE IF NOT EXISTS `orders_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `orders_id` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL,
  `price` float(12,2) DEFAULT NULL,
  `discount` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `sum` float(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_id` (`orders_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `orders_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `orders_status`
--

CREATE TABLE IF NOT EXISTS `orders_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `orders_status`
--

INSERT INTO `orders_status` (`id`, `name`) VALUES
(1, 'Новый'),
(2, 'Обрабатывается'),
(3, 'Оплачен'),
(4, 'Отменен'),
(5, 'Закрыт');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  `form` enum('0','1','2') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `sort`, `active`, `url`, `form`) VALUES
(27, 0, '1', 'home', '0'),
(39, 0, '1', 'otkritie-avto', '0'),
(41, 0, '1', 'otkritie-seyfov', '0'),
(42, 0, '1', 'izgotovlenie-klyuchey', '0'),
(43, 0, '1', 'zamena-i-ustanovka-zamkov', '0'),
(44, 0, '1', 'remont-i-servis-zamkov', '0'),
(45, 0, '1', 'discount', '2'),
(46, 0, '1', 'glavnoe-menyuk2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `params`
--

CREATE TABLE IF NOT EXISTS `params` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0' COMMENT '1-выводить/0-не выводить',
  `url` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='справочник: Свойства продукции' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `params`
--

INSERT INTO `params` (`id`, `sub`, `sort`, `active`, `url`) VALUES
(1, NULL, 0, '1', ''),
(2, NULL, 0, '1', ''),
(3, 1, 0, '1', ''),
(4, 1, 0, '1', ''),
(5, 2, 0, '1', ''),
(6, 2, 0, '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `params_product`
--

CREATE TABLE IF NOT EXISTS `params_product` (
  `params_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  KEY `params_id` (`params_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='смежная таблица:Настройки характеристик для продукции';

--
-- Dumping data for table `params_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `active`, `sort`) VALUES
(1, '1', 0),
(2, '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--

CREATE TABLE IF NOT EXISTS `photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photos_id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `photos_id` (`photos_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `photo`
--

INSERT INTO `photo` (`id`, `photos_id`, `sort`, `active`) VALUES
(1, 1, 5, '0'),
(3, 1, 1, '1'),
(4, 1, 3, '1'),
(5, 1, 4, '0'),
(6, 1, 6, '1'),
(7, 1, 2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `photos`
--

INSERT INTO `photos` (`id`, `sub`, `sort`, `active`, `url`) VALUES
(1, NULL, 3, '1', 'glavnoe-men-');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brend_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `price` float(12,2) NOT NULL,
  `discount` int(11) NOT NULL,
  `cnt` int(11) DEFAULT NULL,
  `url` varchar(128) DEFAULT NULL,
  `active` enum('0','1') DEFAULT '0' COMMENT '1-ON / 0- OFF',
  `date_add` datetime DEFAULT '0000-00-00 00:00:00',
  `date_edit` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `brend_id`, `status_id`, `code`, `price`, `discount`, `cnt`, `url`, `active`, `date_add`, `date_edit`, `sort`) VALUES
(9, 0, 0, '436211Е', 70.00, 0, NULL, 'bavarskaya', '1', '2012-06-07 18:05:29', '2012-09-07 15:12:32', 4),
(10, 9, 0, 'B00006UK8Q', 65.00, 5, 0, 'chiken-ranch', '1', '2012-06-07 18:09:53', '2012-09-12 17:16:48', 3),
(15, 0, 0, '', 0.00, 0, 1, 'glavnoe-menyu', '1', '2012-08-16 12:51:58', '2012-09-12 17:16:46', 1),
(16, 0, 0, '', 0.00, 0, 1, 'filtri-tovarov', '1', '2012-08-16 12:52:40', '2012-09-13 16:46:56', 0),
(17, 0, 0, '', 0.00, 0, 1, 'yuriy', '1', '2012-08-16 12:57:25', '2012-09-07 15:20:50', 5);

-- --------------------------------------------------------

--
-- Table structure for table `product_catalog`
--

CREATE TABLE IF NOT EXISTS `product_catalog` (
  `product_id` int(11) DEFAULT NULL,
  `catalog_id` int(11) DEFAULT NULL,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_catalog`
--

INSERT INTO `product_catalog` (`product_id`, `catalog_id`) VALUES
(9, 10),
(17, 13),
(15, 10),
(10, 10),
(16, 2);

-- --------------------------------------------------------

--
-- Table structure for table `product_photo`
--

CREATE TABLE IF NOT EXISTS `product_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `product_photo`
--

INSERT INTO `product_photo` (`id`, `product_id`, `active`, `sort`) VALUES
(9, 9, '1', 0),
(10, 9, '1', 0),
(11, 9, '1', 0),
(12, 9, '1', 0),
(13, 17, '1', 0),
(14, 17, '1', 0),
(15, 17, '1', 0),
(16, 16, '1', 4),
(17, 16, '0', 1),
(18, 16, '0', 2),
(19, 16, '1', 3);

-- --------------------------------------------------------

--
-- Table structure for table `product_status`
--

CREATE TABLE IF NOT EXISTS `product_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(128) NOT NULL,
  `comment` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `product_status`
--

INSERT INTO `product_status` (`id`, `url`, `comment`) VALUES
(4, 'discount', 'Акции'),
(5, 'hot-offers', 'Специальные предложения'),
(6, 'novetly', 'Новинки');

-- --------------------------------------------------------

--
-- Table structure for table `product_status_set`
--

CREATE TABLE IF NOT EXISTS `product_status_set` (
  `product_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_status_set`
--

INSERT INTO `product_status_set` (`product_id`, `status_id`) VALUES
(15, 4),
(15, 6),
(10, 5),
(16, 4),
(16, 5),
(16, 6);

-- --------------------------------------------------------

--
-- Table structure for table `ru_catalog`
--

CREATE TABLE IF NOT EXISTS `ru_catalog` (
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_catalog`
--

INSERT INTO `ru_catalog` (`cat_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(2, 'Литература', 'ф', 'фф', 'ввв', '&lt;p&gt;описени&lt;/p&gt;'),
(3, 'Услуги', 'в', 'ввввввввввв', 'ввввввввввввввв', '&lt;p&gt;ываыва&lt;/p&gt;'),
(9, 'Каталог товаровjj', '', '', '', ''),
(10, 'Игрушки', '', '', '', ''),
(11, 'Украшения', '', '', '', ''),
(12, 'Декор интерьера', '', '', '', ''),
(13, 'Упаковка', '', '', '', ''),
(15, 'Открытки', '', '', '', ''),
(16, 'Котэ', '', '', '', ''),
(17, 'Зайчики', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_delivery`
--

CREATE TABLE IF NOT EXISTS `ru_delivery` (
  `delivery_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `delivery_id` (`delivery_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_delivery`
--

INSERT INTO `ru_delivery` (`delivery_id`, `name`) VALUES
(5, 'Курьером'),
(6, 'Самовывоз'),
(7, 'Новая почта');

-- --------------------------------------------------------

--
-- Table structure for table `ru_info_blocks`
--

CREATE TABLE IF NOT EXISTS `ru_info_blocks` (
  `info_id` int(11) DEFAULT NULL COMMENT '��� �����',
  `name` varchar(64) DEFAULT NULL COMMENT '������������',
  `body` text,
  KEY `pages_id` (`info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU: ���� ����� ';

--
-- Dumping data for table `ru_info_blocks`
--

INSERT INTO `ru_info_blocks` (`info_id`, `name`, `body`) VALUES
(1, 'Верхние контакты', '&lt;p&gt;&#040;066&#041; 314 15 23&lt;br /&gt; &#040;066&#041; 314 15 23&lt;/p&gt;'),
(3, 'Рекомендации', '&lt;h3&gt;Рекомендации&lt;/h3&gt;\r\n&lt;p&gt;Как правильно измерять артериальное давление&lt;br /&gt;Точность полученных результатов, гарантия правильной диагностики гипертонии зависят от соблюдения некоторых правил. Для определения артериального давления имеют значение положение пациента, сопутствующие обстоятельства, оснащение и владение техникой измерения.&lt;/p&gt;\r\n&lt;p&gt;Как правильно принимать таблетки&lt;br /&gt;Если таблетка имеет овальную форму и покрыта оболочкой, ее следует глотать не разжевывая &#040;это же относится к порошкам в капсулах&#041;. кардиограф Остальные таблетки и порошки перед приемом внутрь желательно измельчить и запить жидкостью.&lt;/p&gt;\r\n&lt;p&gt;Как правильно измерять артериальное давление&lt;br /&gt;Точность полученных результатов, гарантия правильной диагностики гипертонии зависят от соблюдения некоторых правил. Для определения артериального давления имеют значение положение пациента, сопутствующие обстоятельства, оснащение и владение техникой измерения.&lt;/p&gt;'),
(4, 'Бонус', '&lt;p&gt;&lt;a href=&quot;/discount&quot;&gt;&lt;img src=&quot;/files/storage/images/ban4.png&quot; alt=&quot;&quot; /&gt;&lt;/a&gt;&lt;/p&gt;'),
(5, 'Бренды', '&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Бренды&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;img src=&quot;/files/storage/images/ban1.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt;&lt;img src=&quot;/files/storage/images/ban2.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt;&lt;img src=&quot;/files/storage/images/ban3.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;'),
(6, 'Баннер на главной &#040;верхний&#041;', '&lt;p&gt;&lt;img src=&quot;/files/storage/ban.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;'),
(7, 'Баннер на главной &#040;нижний&#041;', '&lt;p&gt;&lt;img src=&quot;/files/storage/images/banner.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `ru_menu`
--

CREATE TABLE IF NOT EXISTS `ru_menu` (
  `menu_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `menu_id` (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_menu`
--

INSERT INTO `ru_menu` (`menu_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(78, 'Главное меню', '', '', '', ''),
(79, 'photo', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_meta_data`
--

CREATE TABLE IF NOT EXISTS `ru_meta_data` (
  `meta_id` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `body` longtext,
  `keywords` text,
  `description` text,
  KEY `meta_id` (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU:SEO оптимизация';

--
-- Dumping data for table `ru_meta_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `ru_news`
--

CREATE TABLE IF NOT EXISTS `ru_news` (
  `news_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body_m` varchar(256) NOT NULL,
  `body` longtext,
  KEY `news_id` (`news_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_news`
--

INSERT INTO `ru_news` (`news_id`, `name`, `title`, `keywords`, `description`, `body_m`, `body`) VALUES
(4, 'Новостной заголовок 2', '', '', '', 'Создание одного приверженного покупателя все же амбивалентно. Привлечение всей же аудитории стабилизирует.', '&lt;p&gt;Тонометры - приборы которые измеряют давление крови в организме человека.&lt;/p&gt;'),
(5, 'Новостной заголовок', '', '', '', 'Создание одного приверженного покупателя все же амбивалентно. Привлечение всей же аудитории стабилизирует.', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_pages`
--

CREATE TABLE IF NOT EXISTS `ru_pages` (
  `pages_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `pages_id` (`pages_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_pages`
--

INSERT INTO `ru_pages` (`pages_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(27, 'Главная', '', '', '', ''),
(39, 'Открытие авто', '', '', '', 'кккк'),
(41, 'Открытие сейфов', '', '', '', ''),
(42, 'Изготовление ключей', '', '', '', ''),
(43, 'Замена и установка замков', '', '', '', ''),
(44, 'Ремонт и сервис замков', '', '', '', ''),
(45, 'Описание скидки', '', '', '', ''),
(46, 'Главное менюk', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_params`
--

CREATE TABLE IF NOT EXISTS `ru_params` (
  `params_id` int(11) DEFAULT NULL COMMENT 'Код группы категории',
  `name` varchar(64) DEFAULT NULL COMMENT 'Наименование категории номенклатуры',
  `info` text,
  KEY `params_id` (`params_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU справочник: Свойства продукции';

--
-- Dumping data for table `ru_params`
--

INSERT INTO `ru_params` (`params_id`, `name`, `info`) VALUES
(1, 'Мощность', NULL),
(2, 'Тип нагрева', NULL),
(3, '24кВт', NULL),
(4, '21-32кВт', NULL),
(5, 'отопление&#043;ГВС', NULL),
(6, 'отопление', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ru_payment`
--

CREATE TABLE IF NOT EXISTS `ru_payment` (
  `payment_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `payment_id` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_payment`
--

INSERT INTO `ru_payment` (`payment_id`, `name`) VALUES
(1, 'Новости сайта'),
(2, 'Приват Банк');

-- --------------------------------------------------------

--
-- Table structure for table `ru_photo`
--

CREATE TABLE IF NOT EXISTS `ru_photo` (
  `photo_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_photo`
--

INSERT INTO `ru_photo` (`photo_id`, `name`) VALUES
(1, 'Lexus'),
(3, '153746_272837'),
(4, 'Aston_Martin_AMV10_sports_cars_wallpapers'),
(5, 'Lexus_LF-A_Sports,_Car_Concept,_2007'),
(6, 'sports car wallpaper-5'),
(7, '153746_272837');

-- --------------------------------------------------------

--
-- Table structure for table `ru_photos`
--

CREATE TABLE IF NOT EXISTS `ru_photos` (
  `photos_id` int(11) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `body_m` varchar(255) DEFAULT NULL,
  `body` text,
  `title` varchar(128) DEFAULT NULL,
  `keywords` text,
  `description` text,
  KEY `photos_id` (`photos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_photos`
--

INSERT INTO `ru_photos` (`photos_id`, `name`, `body_m`, `body`, `title`, `keywords`, `description`) VALUES
(1, 'Альбом 2', NULL, '&lt;p&gt;ооооооооооооооо в&lt;/p&gt;', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_product`
--

CREATE TABLE IF NOT EXISTS `ru_product` (
  `product_id` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL,
  `body_m` longtext,
  `body` longtext,
  `title` varchar(128) DEFAULT NULL,
  `keywords` text,
  `description` text,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_product`
--

INSERT INTO `ru_product` (`product_id`, `name`, `body_m`, `body`, `title`, `keywords`, `description`) VALUES
(9, 'Баварская', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '&lt;p&gt;Глюкометр&nbsp; Контур ТС &#040;CONTOUR TS&#041; требует всего 0,6 мкл крови и позволяет получить точные результаты уже через 8 секунд. Существует возможность взятия проб крови из разных мест &mdash; кончика пальца, ладони или предплечья.&lt;/p&gt;', '', '', ''),
(10, 'Чикен Ранч', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '', '', ''),
(15, 'Главное меню', '', '', '', '', ''),
(16, 'Фильтры товаров', '', '', '', '', ''),
(17, 'Юрий', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_product_photo`
--

CREATE TABLE IF NOT EXISTS `ru_product_photo` (
  `photo_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `photo_id` (`photo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_product_photo`
--

INSERT INTO `ru_product_photo` (`photo_id`, `name`) VALUES
(9, '153746_272837'),
(10, 'Aston_Martin_AMV10_sports_cars_wallpapers'),
(11, 'Lexus_LF-A_Sports,_Car_Concept,_2007'),
(12, 'sports car wallpaper-5'),
(13, 'sdf'),
(14, 'sdfsdf'),
(15, 'fffffffffff'),
(16, '1261_b'),
(17, '153746_272837'),
(18, 'Aston_Martin_AMV10_sports_cars_wallpapers'),
(19, 'Lexus_LF-A_Sports,_Car_Concept,_2007');

-- --------------------------------------------------------

--
-- Table structure for table `ru_product_status`
--

CREATE TABLE IF NOT EXISTS `ru_product_status` (
  `product_status_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `product_status_id` (`product_status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_product_status`
--

INSERT INTO `ru_product_status` (`product_status_id`, `name`) VALUES
(4, 'Акции'),
(5, 'Специальные предложения'),
(6, 'Новинки');

-- --------------------------------------------------------

--
-- Table structure for table `ru_slider`
--

CREATE TABLE IF NOT EXISTS `ru_slider` (
  `slider_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `slider_id` (`slider_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_slider`
--

INSERT INTO `ru_slider` (`slider_id`, `name`) VALUES
(3, 'Новости сайта');

-- --------------------------------------------------------

--
-- Table structure for table `ru_translate`
--

CREATE TABLE IF NOT EXISTS `ru_translate` (
  `translate_id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text,
  PRIMARY KEY (`translate_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='TEXT RU: ������� ��������' AUTO_INCREMENT=232 ;

--
-- Dumping data for table `ru_translate`
--

INSERT INTO `ru_translate` (`translate_id`, `value`) VALUES
(1, 'Создание сайта'),
(3, 'Все права защищены © 2012'),
(4, 'Новости'),
(7, 'Обратная связь'),
(8, 'ФИО'),
(9, 'Город'),
(10, 'Телефон'),
(11, 'поля обязательные для заполнения'),
(12, 'Отправить'),
(68, 'Вы искали'),
(70, 'Архив уроков'),
(72, 'Ничего не найдено'),
(82, 'Фамилия'),
(83, 'Имя'),
(84, 'Адрес'),
(85, 'Мобильный тел.'),
(86, 'Авторизация'),
(106, 'Поля * являются обязательными'),
(108, 'Неправильный email'),
(137, 'подробнее'),
(155, 'E-mail'),
(156, 'Сообщение'),
(157, 'Архив статей'),
(158, 'Все новости'),
(159, 'Последние новости'),
(165, 'Gletcher'),
(167, 'Последние комментарии'),
(168, 'Информационные материалы'),
(169, 'Задай вопрос'),
(170, 'Регистрация'),
(171, 'После проверки Ваш комментарий будет добавлен'),
(172, 'Видеоархив'),
(173, 'Отзывы'),
(174, 'Данные успешно сохранены'),
(175, 'Регистрация к этому руководителю'),
(176, 'Вы успешно зарегистрированы'),
(177, 'Неправильный код подтверждения'),
(178, 'Данный email зарегистрирован!'),
(179, 'Сообщение отправлено!'),
(180, 'Следующий'),
(181, 'Заказать'),
(182, 'Поиск'),
(183, 'Оформить заказ'),
(184, 'Описание'),
(185, 'Характеристики'),
(186, 'Меню'),
(188, 'Все'),
(190, 'Неверный формат телефона'),
(191, 'Вход'),
(193, 'Пароль'),
(194, 'E-mail не зарегистрирован'),
(195, 'Вы успешно авторизованы'),
(196, 'Сохранить'),
(197, 'Мои данные'),
(198, 'Мои заказы'),
(199, 'Новый пароль'),
(200, 'Старый пароль'),
(201, 'Почтовый индекс'),
(202, 'Корзина пуста'),
(203, 'Комментарии к заказу'),
(204, 'Выйти'),
(209, 'Главная'),
(210, 'E-mail добавлен в  базу!'),
(211, 'Подписка'),
(212, 'Подписаться'),
(213, 'Способ доставки'),
(214, 'Способ оплаты'),
(216, 'Бренды'),
(217, 'Статьи'),
(218, 'Все статьи'),
(219, 'Последние статьи'),
(220, 'Фотогалерея'),
(221, 'Name'),
(222, 'Удалить'),
(223, 'Сумма'),
(224, 'Кол-во'),
(225, 'Цена'),
(226, 'Итого'),
(227, 'Другие товары'),
(228, 'К оплате'),
(229, 'В корзине товаров'),
(231, '&lt;b&gt;Благодарим Вас за заказ!&lt;/b&gt;&lt;br /&gt;В ближайшее время с Вами свяжется менеджер по указанному Вами E-mail!');

-- --------------------------------------------------------

--
-- Table structure for table `ru_video`
--

CREATE TABLE IF NOT EXISTS `ru_video` (
  `video_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  KEY `video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_video`
--


-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(128) NOT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `url`, `active`, `sort`) VALUES
(3, 'http://healthpoint.com.ua/catalog/akkutrend-plyus2', '1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `translate`
--

CREATE TABLE IF NOT EXISTS `translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(128) DEFAULT NULL,
  `value_et` text,
  `comment` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='TEXT RU: ' AUTO_INCREMENT=232 ;

--
-- Dumping data for table `translate`
--

INSERT INTO `translate` (`id`, `key`, `value_et`, `comment`) VALUES
(1, 'skylogic', NULL, 'Создание сайта'),
(3, 'copyright', NULL, 'Копирайт'),
(4, 'news', NULL, 'Новости'),
(7, 'feelback', NULL, 'Обратная связь'),
(8, 'fio', NULL, 'ФИО'),
(9, 'city', NULL, 'Город'),
(10, 'phone', NULL, 'Телефон'),
(11, 'fields', NULL, 'поля обязательные для заполнения'),
(12, 'send_message', NULL, 'Отправить'),
(68, 'search', NULL, 'Вы искали'),
(70, 'arxiv_info', NULL, 'Архив уроков'),
(72, 'not_found', NULL, 'Ничего не найдено'),
(82, 'sname', NULL, 'Фамилия'),
(83, 'name', NULL, 'Имя'),
(84, 'address', NULL, 'Адрес'),
(85, 'phone2', NULL, 'Мобильный тел.'),
(86, 'auth', NULL, 'Авторизация'),
(106, 'required', NULL, 'Поля * являются обязательными'),
(108, 'wrong_email', NULL, 'Неправильный email'),
(137, 'read_more', NULL, 'подробнее'),
(155, 'email', NULL, 'E-mail'),
(156, 'message', NULL, 'Сообщение'),
(157, 'arxiv_news', NULL, 'Архив статей'),
(158, 'all_news', NULL, 'Все новости'),
(159, 'last_news', NULL, 'Последние новости'),
(165, 'sitename', NULL, 'Название сайта'),
(167, 'last_comments', NULL, 'Последние комментарии'),
(168, 'info_block', NULL, 'Информационные материалы'),
(169, 'ask', NULL, 'Задай вопрос'),
(170, 'sign_up', NULL, 'Регистрация'),
(171, 'comment_add', NULL, 'После проверки Ваш комментарий будет добавлен'),
(172, 'video_name', NULL, 'Видеоархив'),
(173, 'comments', NULL, 'Отзывы'),
(174, 'save_data', NULL, 'Данные успешно сохранены'),
(175, 'user_reg', NULL, 'Регистрация к этому руководителю'),
(176, 'sign_up_yes', NULL, 'Вы успешно зарегистрированы'),
(177, 'wrong_code', NULL, 'Неправильный код подтверждения'),
(178, 'email_exists', NULL, 'Данный email зарегистрирован!'),
(179, 'message_sent', NULL, 'Сообщение отправлено!'),
(180, 'next', NULL, 'Следующий'),
(181, 'buy', NULL, 'Купить'),
(182, 'search_name', NULL, 'Поиск'),
(183, 'to_order', NULL, 'Оформить заказ'),
(184, 'desc', NULL, 'Описание'),
(185, 'param', NULL, 'Характеристики'),
(186, 'catalog', NULL, 'Каталог'),
(188, 'all', NULL, 'Все'),
(190, 'wrong_phone', NULL, 'Неверный формат телефона'),
(191, 'enter', NULL, 'Вход'),
(193, 'password', NULL, 'Пароль'),
(194, 'email_no_exists', NULL, 'E-mail не зарегистрирован'),
(195, 'auth_yes', NULL, 'Вы успешно авторизованы'),
(196, 'save', NULL, 'Сохранить'),
(197, 'my_data', NULL, 'Мои данные'),
(198, 'my_orders', NULL, 'Мои заказы'),
(199, 'new_pass', NULL, 'Новый пароль'),
(200, 'old_pass', NULL, 'Старый пароль'),
(201, 'post_index', NULL, 'Почтовый индекс'),
(202, 'cart_empty', NULL, 'Корзина пуста'),
(203, 'comments_order', NULL, 'Комментарии к заказу'),
(204, 'exit', NULL, 'Выйти'),
(209, 'main', NULL, 'Ссылка на главную в хленых крошках'),
(210, 'email_added', NULL, 'E-mail добавлен в  базу!'),
(211, 'mailer2', NULL, 'Подписка'),
(212, 'mailer', NULL, 'Подписаться'),
(213, 'delivery', NULL, 'Способ доставки'),
(214, 'payment', NULL, 'Способ оплаты'),
(216, 'brend', NULL, 'Бренды'),
(217, 'article', NULL, 'Статьи'),
(218, 'all_article', NULL, 'Все статьи'),
(219, 'last_article', NULL, 'Последние статьи'),
(220, 'photos', NULL, 'Фотогалерея'),
(221, 'title', NULL, 'Название'),
(222, 'delete', NULL, 'Удалить'),
(223, 'sum', NULL, 'Сумма'),
(224, 'amount', NULL, 'Кол-во'),
(225, 'price', NULL, 'Цена'),
(226, 'total', NULL, 'Итого'),
(227, 'other_product', NULL, 'Другие товары'),
(228, 'payable', NULL, 'К оплате'),
(229, 'in_cart', NULL, 'В корзине товаров'),
(231, 'message_sent_order', NULL, 'Благодарим Вас за заказ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL DEFAULT '0',
  `referral_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `surname` varchar(100) DEFAULT NULL,
  `patronymic` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `info` varchar(512) NOT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `skype` varchar(32) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `post_index` varchar(100) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `discount` decimal(4,2) DEFAULT NULL,
  `active_email` int(11) DEFAULT NULL,
  `mailer` int(11) DEFAULT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `status_id`, `referral_id`, `name`, `surname`, `patronymic`, `pass`, `email`, `info`, `phone`, `skype`, `city`, `address`, `post_index`, `start_date`, `discount`, `active_email`, `mailer`, `active`) VALUES
(16, 1, 0, 'Юрий', NULL, NULL, '438d54d0b9e7675cae51d1c85248b74c', 'thefactorial@gmail.com', '', '&#043;38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', '54435345', '2012-07-06 15:37:08', NULL, 0, NULL, '1'),
(17, 1, 0, 'Новости сайта', NULL, NULL, 'd1ad5959a729f97b5c90588da7f8f14c', 'www_alex@list.ru', '', '&#043;38 &#040;097&#041;569-83-92', '', 'odessa', 'ул. м Арнаутская,48', '54435345', '2012-07-06 15:38:41', NULL, 2, NULL, '1');

-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE IF NOT EXISTS `user_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`id`, `comment`) VALUES
(1, 'Пользователь'),
(2, 'Менеджер');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE IF NOT EXISTS `video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` text NOT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `video`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `en_brend`
--
ALTER TABLE `en_brend`
  ADD CONSTRAINT `en_brend_ibfk_1` FOREIGN KEY (`brend_id`) REFERENCES `brend` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_catalog`
--
ALTER TABLE `en_catalog`
  ADD CONSTRAINT `en_catalog_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `en_catalog_ibfk_2` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `en_catalog_ibfk_3` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `en_catalog_ibfk_4` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_delivery`
--
ALTER TABLE `en_delivery`
  ADD CONSTRAINT `en_delivery_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `delivery` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_info_blocks`
--
ALTER TABLE `en_info_blocks`
  ADD CONSTRAINT `FK_en_info_blocks_id` FOREIGN KEY (`info_id`) REFERENCES `info_blocks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_menu`
--
ALTER TABLE `en_menu`
  ADD CONSTRAINT `en_menu_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_meta_data`
--
ALTER TABLE `en_meta_data`
  ADD CONSTRAINT `en_meta_data_ibfk_1` FOREIGN KEY (`meta_id`) REFERENCES `meta_data` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_news`
--
ALTER TABLE `en_news`
  ADD CONSTRAINT `en_news_ibfk_1` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_pages`
--
ALTER TABLE `en_pages`
  ADD CONSTRAINT `FK_en_pages_id` FOREIGN KEY (`pages_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_params`
--
ALTER TABLE `en_params`
  ADD CONSTRAINT `en_params_ibfk_1` FOREIGN KEY (`params_id`) REFERENCES `params` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_payment`
--
ALTER TABLE `en_payment`
  ADD CONSTRAINT `en_payment_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_photo`
--
ALTER TABLE `en_photo`
  ADD CONSTRAINT `en_photo_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_photos`
--
ALTER TABLE `en_photos`
  ADD CONSTRAINT `en_photos_ibfk_1` FOREIGN KEY (`photos_id`) REFERENCES `photos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_product`
--
ALTER TABLE `en_product`
  ADD CONSTRAINT `en_product_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_product_photo`
--
ALTER TABLE `en_product_photo`
  ADD CONSTRAINT `en_product_photo_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `product_photo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_slider`
--
ALTER TABLE `en_slider`
  ADD CONSTRAINT `en_slider_ibfk_1` FOREIGN KEY (`slider_id`) REFERENCES `slider` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_translate`
--
ALTER TABLE `en_translate`
  ADD CONSTRAINT `en_translate_ibfk_1` FOREIGN KEY (`translate_id`) REFERENCES `translate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `en_video`
--
ALTER TABLE `en_video`
  ADD CONSTRAINT `en_video_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `video` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`sub`) REFERENCES `menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `moderators`
--
ALTER TABLE `moderators`
  ADD CONSTRAINT `moderators_ibfk_1` FOREIGN KEY (`type_moderator`) REFERENCES `moderators_type` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `orders_product`
--
ALTER TABLE `orders_product`
  ADD CONSTRAINT `orders_product_ibfk_1` FOREIGN KEY (`orders_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `params_product`
--
ALTER TABLE `params_product`
  ADD CONSTRAINT `params_product_ibfk_1` FOREIGN KEY (`params_id`) REFERENCES `params` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `params_product_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `photo`
--
ALTER TABLE `photo`
  ADD CONSTRAINT `photo_ibfk_1` FOREIGN KEY (`photos_id`) REFERENCES `photos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_catalog`
--
ALTER TABLE `product_catalog`
  ADD CONSTRAINT `product_catalog_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_photo`
--
ALTER TABLE `product_photo`
  ADD CONSTRAINT `product_photo_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_status_set`
--
ALTER TABLE `product_status_set`
  ADD CONSTRAINT `product_status_set_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_catalog`
--
ALTER TABLE `ru_catalog`
  ADD CONSTRAINT `ru_catalog_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_catalog_ibfk_2` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_catalog_ibfk_3` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_catalog_ibfk_4` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_delivery`
--
ALTER TABLE `ru_delivery`
  ADD CONSTRAINT `ru_delivery_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `delivery` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_info_blocks`
--
ALTER TABLE `ru_info_blocks`
  ADD CONSTRAINT `FK_ru_info_blocks_id` FOREIGN KEY (`info_id`) REFERENCES `info_blocks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_menu`
--
ALTER TABLE `ru_menu`
  ADD CONSTRAINT `ru_menu_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_meta_data`
--
ALTER TABLE `ru_meta_data`
  ADD CONSTRAINT `ru_meta_data_ibfk_1` FOREIGN KEY (`meta_id`) REFERENCES `meta_data` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_news`
--
ALTER TABLE `ru_news`
  ADD CONSTRAINT `ru_news_ibfk_1` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_pages`
--
ALTER TABLE `ru_pages`
  ADD CONSTRAINT `FK_ru_pages_id` FOREIGN KEY (`pages_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_params`
--
ALTER TABLE `ru_params`
  ADD CONSTRAINT `ru_params_ibfk_1` FOREIGN KEY (`params_id`) REFERENCES `params` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_payment`
--
ALTER TABLE `ru_payment`
  ADD CONSTRAINT `ru_payment_ibfk_1` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_photo`
--
ALTER TABLE `ru_photo`
  ADD CONSTRAINT `ru_photo_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_photos`
--
ALTER TABLE `ru_photos`
  ADD CONSTRAINT `ru_photos_ibfk_1` FOREIGN KEY (`photos_id`) REFERENCES `photos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_product`
--
ALTER TABLE `ru_product`
  ADD CONSTRAINT `ru_product_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_product_photo`
--
ALTER TABLE `ru_product_photo`
  ADD CONSTRAINT `ru_product_photo_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `product_photo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_product_status`
--
ALTER TABLE `ru_product_status`
  ADD CONSTRAINT `en_product_status_ibfk_1` FOREIGN KEY (`product_status_id`) REFERENCES `product_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_product_status_ibfk_1` FOREIGN KEY (`product_status_id`) REFERENCES `product_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_slider`
--
ALTER TABLE `ru_slider`
  ADD CONSTRAINT `ru_slider_ibfk_1` FOREIGN KEY (`slider_id`) REFERENCES `slider` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_translate`
--
ALTER TABLE `ru_translate`
  ADD CONSTRAINT `ru_translate_ibfk_1` FOREIGN KEY (`translate_id`) REFERENCES `translate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_video`
--
ALTER TABLE `ru_video`
  ADD CONSTRAINT `ru_video_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `video` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`status_id`) REFERENCES `user_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
