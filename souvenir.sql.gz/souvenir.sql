-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 07, 2012 at 02:16 PM
-- Server version: 5.1.40
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `souvenir`
--

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE IF NOT EXISTS `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  `date` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `article`
--

INSERT INTO `article` (`id`, `sort`, `active`, `url`, `date`) VALUES
(4, 0, '1', 'glavnoe-menyu', '2012-08-14 11:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `bascket`
--

CREATE TABLE IF NOT EXISTS `bascket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `product_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `session_id` varchar(64) NOT NULL,
  `price` float(12,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `bascket`
--

INSERT INTO `bascket` (`id`, `date`, `product_id`, `amount`, `user_id`, `session_id`, `price`) VALUES
(22, '2012-08-01 16:49:13', 10, 8, 0, '76d2b594052e31700972f1d6c5efcc4e', 65.00),
(23, '2012-08-01 16:49:42', 9, 2, 0, '76d2b594052e31700972f1d6c5efcc4e', 70.00),
(24, '2012-08-01 18:02:39', 14, 3, 0, '76d2b594052e31700972f1d6c5efcc4e', 80.00),
(25, '2012-08-15 16:32:37', 10, 1, 0, '6d7f35c30daf441a7f220e8e567c9325', 65.00),
(26, '2012-08-15 16:32:42', 14, 1, 0, '6d7f35c30daf441a7f220e8e567c9325', 80.00),
(27, '2012-08-16 12:36:49', 9, 1, 0, 'b88eae5ab8309c8291de983fcc851f75', 70.00),
(30, '2012-09-06 17:47:20', 14, 2, 0, '62490aeaf2c984dd41ed32bc54666ca0', 80.00);

-- --------------------------------------------------------

--
-- Table structure for table `catalog`
--

CREATE TABLE IF NOT EXISTS `catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `catalog`
--

INSERT INTO `catalog` (`id`, `sub`, `sort`, `active`, `url`) VALUES
(2, NULL, 3, '1', 'literatura'),
(3, NULL, 2, '1', 'uslugi'),
(9, NULL, 1, '1', 'katalog-tovarov'),
(10, 9, 1, '1', 'igrushki'),
(11, 9, 2, '1', 'ukrasheniya'),
(12, 9, 3, '1', 'dekor-interera'),
(13, 9, 5, '1', 'upakovka'),
(15, 9, 4, '1', 'otkritki'),
(16, 10, 0, '1', 'kote'),
(17, 10, 0, '1', 'zaychiki'),
(18, 10, 0, '1', 'mishki');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(2) DEFAULT 'ru',
  `author` varchar(128) DEFAULT NULL,
  `photo` varchar(128) NOT NULL,
  `text` text,
  `date` datetime DEFAULT '0000-00-00 00:00:00',
  `content_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(128) DEFAULT NULL,
  `session_id` varchar(255) NOT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `language`, `author`, `photo`, `text`, `date`, `content_id`, `type`, `session_id`, `active`) VALUES
(5, 'ru', 'Саша Ким', '', 'asdasdasd', '2012-07-07 18:01:58', 46, 'pages', '57ef03290ee1449c34a6083073910379', '1'),
(6, 'ru', 'Саша Ким', 'http://cs11234.userapi.com/u8657787/e_0f15b748.jpg', 'asdasd', '2012-07-07 18:02:25', 46, 'pages', '57ef03290ee1449c34a6083073910379', '1'),
(7, 'ru', 'Саша Ким', 'http://cs11234.userapi.com/u8657787/e_0f15b748.jpg', 'asdasdad', '2012-07-07 18:02:57', 46, 'pages', '57ef03290ee1449c34a6083073910379', '1');

-- --------------------------------------------------------

--
-- Table structure for table `const`
--

CREATE TABLE IF NOT EXISTS `const` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `value` text,
  `comment` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='��������� �����' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `const`
--

INSERT INTO `const` (`id`, `name`, `value`, `comment`) VALUES
(8, 'email', 'www_alex@list.ru', 'Контактный E-mail'),
(9, 'sitename', 'Студия подарков', 'Название сайта'),
(10, 'google', '', 'Google Analitics'),
(12, 'col_product', '10', 'Кол-во товаров в каталоге'),
(13, 'limit_news_block', '3', 'Кол-во новостей слева');

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE IF NOT EXISTS `currency` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `icon` varchar(5) NOT NULL,
  `rate` float(12,4) NOT NULL,
  `name` varchar(32) NOT NULL,
  `position` int(1) NOT NULL,
  `base` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `icon`, `rate`, `name`, `position`, `base`) VALUES
(1, 'грн.', 0.0000, 'Гривна', 1, '1'),
(2, '€', 10.0154, 'Евро', 0, '0'),
(3, '$', 8.0900, 'Доллар', 0, '0');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE IF NOT EXISTS `delivery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `price` float(12,2) NOT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`id`, `name`, `price`, `active`, `sort`) VALUES
(1, 'Курьером', 110.00, '1', 1),
(2, 'Самовывоз', 0.00, '1', 2);

-- --------------------------------------------------------

--
-- Table structure for table `email`
--

CREATE TABLE IF NOT EXISTS `email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `email`
--


-- --------------------------------------------------------

--
-- Table structure for table `include_cod`
--

CREATE TABLE IF NOT EXISTS `include_cod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `value` text,
  `coment` text,
  `urln` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='��� ��� ������� �� ��������(�������� �������)' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `include_cod`
--


-- --------------------------------------------------------

--
-- Table structure for table `info_blocks`
--

CREATE TABLE IF NOT EXISTS `info_blocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0' COMMENT '1-��������/0-�� ��������',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='���� ����� �� �����' AUTO_INCREMENT=8 ;

--
-- Dumping data for table `info_blocks`
--

INSERT INTO `info_blocks` (`id`, `sort`, `active`) VALUES
(1, 1, '0'),
(3, 3, '0'),
(4, 2, '0'),
(5, 4, '0'),
(6, 5, '0'),
(7, 6, '0');

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE IF NOT EXISTS `language` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domen` varchar(255) NOT NULL DEFAULT '',
  `language` varchar(20) DEFAULT NULL,
  `comment` varchar(128) DEFAULT NULL,
  `icon` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domen` (`domen`),
  UNIQUE KEY `language` (`language`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='���������� ������' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`id`, `domen`, `language`, `comment`, `icon`) VALUES
(2, '', 'ru', 'Russian', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  `form` enum('0','1','2') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `sub`, `sort`, `active`, `url`, `form`) VALUES
(64, NULL, 3, '1', 'oplata-dostavka', '0'),
(65, NULL, 1, '1', 'uslugi', '0'),
(68, NULL, 6, '1', 'kontakti', '1'),
(71, NULL, 4, '1', 'sotrudnichestvo', '0'),
(72, NULL, 2, '1', 'literatura', '0');

-- --------------------------------------------------------

--
-- Table structure for table `menu_admin`
--

CREATE TABLE IF NOT EXISTS `menu_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `menu_admin`
--

INSERT INTO `menu_admin` (`id`, `name`) VALUES
(1, 'Веб-сайт'),
(3, 'Пользователи'),
(2, 'Магазин'),
(4, 'Заказы'),
(5, 'Настройки'),
(6, 'Администрирование');

-- --------------------------------------------------------

--
-- Table structure for table `meta_data`
--

CREATE TABLE IF NOT EXISTS `meta_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(128) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `body` longtext,
  `keywords` text,
  `description` text,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='TEXT RU:SEO оптимизация' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `meta_data`
--

INSERT INTO `meta_data` (`id`, `url`, `title`, `body`, `keywords`, `description`, `active`) VALUES
(2, 'http://skycms/catalog/akku-chek', 'Международный коралловый клуб', '&lt;p&gt;ыыыыыыыыыы&lt;/p&gt;', 'фывф', 'ывфывфыв', '1');

-- --------------------------------------------------------

--
-- Table structure for table `moderators`
--

CREATE TABLE IF NOT EXISTS `moderators` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(150) DEFAULT NULL,
  `password` varchar(150) DEFAULT NULL,
  `type_moderator` int(11) DEFAULT '0',
  `name` varchar(128) NOT NULL,
  `surname` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `phone` varchar(128) NOT NULL,
  `skype` varchar(128) NOT NULL,
  `city` varchar(128) NOT NULL,
  `text` text NOT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type_moderator` (`type_moderator`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `moderators`
--

INSERT INTO `moderators` (`id`, `login`, `password`, `type_moderator`, `name`, `surname`, `email`, `phone`, `skype`, `city`, `text`, `active`) VALUES
(1, 'admin', 'fc1d8d8c7f52dc8a94527a27fca15bf5', 1, '', '', '', '', '', '', '', '1'),
(3, 'admin2', 'fc1d8d8c7f52dc8a94527a27fca15bf5', 2, 'Юрий', 'Шкваренко', 'alexddd-kim@rambler.ru', '&#043;380635338366', 'g-xx-s', 'Ильичевскw', 'asdasd', '1');

-- --------------------------------------------------------

--
-- Table structure for table `moderators_auth`
--

CREATE TABLE IF NOT EXISTS `moderators_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `moder_id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_agent` varchar(128) NOT NULL,
  `referer` varchar(256) NOT NULL,
  `ip` varchar(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `moderators_auth`
--

INSERT INTO `moderators_auth` (`id`, `moder_id`, `time`, `user_agent`, `referer`, `ip`) VALUES
(1, 1, '2012-03-13 11:45:08', 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/1', 'http://skycms/admin', '127.0.0.1'),
(2, 1, '2012-03-13 11:45:34', 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2', 'http://skycms/admin', '127.0.0.1'),
(3, 1, '2012-03-13 11:46:10', 'Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2', 'http://skycms/admin', '127.0.0.1');

-- --------------------------------------------------------

--
-- Table structure for table `moderators_permission`
--

CREATE TABLE IF NOT EXISTS `moderators_permission` (
  `moderators_type_id` int(11) NOT NULL,
  `module_id` int(11) NOT NULL,
  `permission` enum('000','400','500','600','700') NOT NULL,
  KEY `moderators_type_id` (`moderators_type_id`),
  KEY `moderators_type_id_2` (`moderators_type_id`),
  KEY `module_id` (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `moderators_permission`
--

INSERT INTO `moderators_permission` (`moderators_type_id`, `module_id`, `permission`) VALUES
(1, 9, '700'),
(1, 59, '700'),
(2, 59, '000'),
(3, 59, '000'),
(1, 57, '700'),
(2, 57, '600'),
(3, 57, '700'),
(1, 2, '700'),
(2, 2, '600'),
(3, 2, '700'),
(1, 63, '700'),
(2, 63, '700'),
(3, 63, '700'),
(1, 61, '700'),
(2, 61, '700'),
(3, 61, '700'),
(1, 58, '700'),
(2, 58, '600'),
(3, 58, '700'),
(1, 60, '700'),
(2, 60, '000'),
(3, 60, '000'),
(1, 67, '700'),
(2, 67, '700'),
(3, 67, '700'),
(1, 76, '700'),
(2, 76, '600'),
(3, 76, '700'),
(1, 79, '700'),
(2, 79, '700'),
(3, 79, '700'),
(1, 80, '700'),
(2, 80, '700'),
(3, 80, '700'),
(1, 87, '700'),
(2, 87, '600'),
(3, 87, '700'),
(1, 89, '700'),
(2, 89, '700'),
(3, 89, '700'),
(1, 100, '700'),
(2, 100, '700'),
(3, 100, '700'),
(1, 101, '700'),
(2, 101, '700'),
(3, 101, '000'),
(2, 9, '000'),
(1, 102, '700'),
(2, 102, '700'),
(3, 102, '700'),
(1, 104, '700'),
(2, 104, '700'),
(3, 104, '700'),
(1, 105, '700'),
(2, 105, '700'),
(3, 105, '700'),
(1, 106, '700'),
(2, 106, '700'),
(3, 106, '700'),
(1, 107, '700'),
(2, 107, '700'),
(3, 107, '700'),
(1, 108, '700'),
(2, 108, '700'),
(3, 108, '700'),
(1, 109, '700'),
(2, 109, '700'),
(3, 109, '700'),
(1, 110, '700'),
(2, 110, '700'),
(3, 110, '700');

-- --------------------------------------------------------

--
-- Table structure for table `moderators_type`
--

CREATE TABLE IF NOT EXISTS `moderators_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `moderators_type`
--

INSERT INTO `moderators_type` (`id`, `comment`) VALUES
(1, 'Супер администратор'),
(2, 'Администратор'),
(3, 'Модератор');

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(1) NOT NULL DEFAULT '1',
  `name` varchar(128) DEFAULT NULL,
  `controller` varchar(128) DEFAULT NULL,
  `tables` varchar(512) NOT NULL,
  `comment` varchar(256) DEFAULT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=111 ;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`id`, `sub`, `name`, `controller`, `tables`, `comment`, `sort`) VALUES
(2, 1, 'Содержимое', 'pages', 'ru_pages,pages', 'Создать и опубликовать страницы, формы, опросы и ссылки.', 2),
(9, 6, 'Модули', 'modules', '', 'Модули', 24),
(57, 1, '﻿Главное меню', 'menu', 'ru_menu,menu', 'Редактирование главного меню\r\n', 1),
(58, 5, '﻿Мета-данные', 'meta', 'meta_data', 'Мета-данные\r\n', 20),
(59, 6, 'Группы модератров', 'moderatorstype', 'moderators_type', '', 23),
(60, 6, 'Модераторы', 'moderators', 'moderators', '', 22),
(61, 5, 'Настройки', 'config', 'const', '', 19),
(63, 1, 'Информационные блоки', 'info', 'ru_info,info', 'Информационные блоки', 3),
(67, 5, 'Переводы', 'translate', '', '', 18),
(76, 2, '﻿Каталог', 'catalog', 'ru_catalog,catalog', 'Просмотреть категории, в которые сгруппированы товары в Вашем магазине.\r\n', 11),
(79, 1, '﻿Новости сайта', 'news', 'ru_news,news', 'Редактировать новости, которые показываются в секции &quot;Новости сайта&quot; на витрине магазина.\r\n', 4),
(80, 1, '﻿Слайдер', 'slider', 'slider', 'Слайдер на главной странице.\r\n', 8),
(87, 3, '﻿Пользователи', 'users', 'users,user_status', 'Редактировать учетные записи пользователей, зарегистрированных в Вашем магазине.\r\n', 17),
(89, 1, '﻿Рассылки', 'mailer', 'email', 'База почтовых ящиков\r\n', 10),
(100, 2, '﻿Заказы', 'orders', 'orders_product,orders', 'Просмотреть, оформить и распечатать счет-фактуру для заказов, сделанных в Вашем магазине.\r\n', 14),
(101, 2, '﻿﻿Товары', 'product', 'ru_product,ru_product_photo,product_photo,product_status_set,product_catalog,product_status,product', 'Просмотреть, добавить и редактировать товары, которые показываются посетителям Вашего магазина.\r\n', 12),
(102, 6, '﻿Валюта', 'currency', 'currency', 'Курс валюты\r\n', 21),
(104, 2, '﻿Способ доставки', 'delivery', 'delivery', 'Способ доставки\r\n', 16),
(105, 2, '﻿Способ оплаты', 'payment', 'payment', 'Способ оплаты\r\n', 15),
(106, 2, '﻿Фильтры товаров', 'params', 'ru_params,params_product,params', 'Фильтры товаров показываются на витрине магазина и позволяют покупателям легко находить нужный товар.\r\n', 13),
(107, 1, '﻿Комментарии и отзывы', 'comments', 'comments,comments_type', 'Комментарии и отзывы пользователей.\r\n', 9),
(108, 1, '﻿Статьи', 'article', 'ru_article,article', 'Редактировать новости, которые показываются в секции &quot;Новости сайта&quot; на витрине магазина.\r\n', 6),
(109, 1, '﻿Фотогалерея', 'photos', 'ru_photo,photo,ru_photos,photos', 'Фотогалерея с разделами\r\n', 5),
(110, 1, '﻿Видео', 'video', 'ru_video,video', 'Виодегалерея\r\n', 7);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  `date` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `sort`, `active`, `url`, `date`) VALUES
(4, 0, '1', 'novostnoy-zagolovok-2', '2012-06-27 11:44:38'),
(5, 0, '1', 'novostnoy-zagolovok', '2012-06-27 12:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_add` datetime DEFAULT '0000-00-00 00:00:00',
  `date_edit` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sum` float(12,2) DEFAULT NULL,
  `discount` int(11) NOT NULL,
  `comment` text,
  `username` varchar(128) NOT NULL,
  `post_index` varchar(256) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `country` varchar(256) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `delivery` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `status_id`, `user_id`, `date_add`, `date_edit`, `sum`, `discount`, `comment`, `username`, `post_index`, `email`, `phone`, `country`, `city`, `address`, `delivery`, `payment`, `amount`) VALUES
(17, 1, 0, '2012-07-04 18:39:34', '2012-07-05 16:00:17', 3190.00, 0, '', 'admin', '', '', '', '', '', '', 0, 0, 2),
(18, 1, 0, '2012-07-06 13:22:35', '2012-07-06 12:22:35', 0.00, 0, 'sddddddddddddddd', 'Главное меню', '54435345', 'thefactorial@gmail.com', '&#043;38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'петровское', 0, 0, 2),
(19, 1, 13, '2012-07-06 13:26:04', '2012-07-06 13:28:01', 990.00, 0, 'hhhhhhhhhh', 'Новости сайта', '345345', 'alexddd-kim@rambler.ru', '&#043;38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 2),
(20, 1, 0, '2012-07-06 14:33:34', '2012-07-06 13:33:34', 967.50, 0, 'sd', 'Новости сайта', '345345', 'alexddd-kim@rambler.ru', '&#043;38 &#040;097&#041;569-83-92', '', 'odessa', 'ул. м Арнаутская,48', 0, 0, 2),
(21, 1, 0, '2012-07-06 14:34:38', '2012-07-06 13:34:38', 967.50, 0, 'ssssssssss', 'Главное меню', '345345', 'alexddd-kim@rambler.ru', '&#043;38 &#040;097&#041; 569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 2),
(22, 1, 0, '2012-07-06 15:24:31', '2012-07-06 14:24:31', 540.00, 0, 'rfffffff', 'Новости сайта', '54435345', 'alexddd-kim@rambler.ru', '&#043;38 &#040;097&#041; 569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 1),
(23, 1, 14, '2012-07-06 15:33:09', '2012-07-06 14:33:09', 967.50, 0, 'sssssssss', 'Юрий', '345345', 'www_alex@list.ru', '&#043;38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 2),
(24, 1, 15, '2012-07-06 15:35:02', '2012-07-06 14:35:02', 967.50, 0, 'ddddddddddddddd', 'Юрий', '54435345', 'thefactorial@gmail.com', '&#043;38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,47', 0, 0, 2),
(25, 1, 16, '2012-07-06 15:37:09', '2012-07-06 14:37:09', 967.50, 0, 'ddddddddddddd', 'Юрий', '54435345', 'thefactorial@gmail.com', '&#043;38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 2),
(26, 1, 17, '2012-07-06 15:38:41', '2012-07-06 14:38:41', 427.50, 0, 'asd', 'Новости сайта', '54435345', 'www_alex@list.ru', '&#043;38 &#040;097&#041;569-83-92', '', 'odessa', 'ул. м Арнаутская,48', 0, 0, 1),
(27, 1, 18, '2012-07-06 15:41:05', '2012-07-06 14:41:05', 967.50, 0, 'ffffffffff', 'Новости сайта', '54435345', 'alex.panomax@gmail.com', '&#043;38 &#040;097&#041;569-83-92', '', 'Одесса', 'ул. м Арнаутская,48', 0, 0, 2),
(28, 1, 0, '2012-07-07 13:22:59', '2012-07-07 14:41:53', 427.50, 0, 'eeeeeeeeeeeeeeeeee', 'Юрий', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041;569-83-92', '', 'Одесса', 'ул. м Арнаутская,48', 0, 2, 1),
(29, 1, 0, '2012-09-04 18:35:39', '2012-09-04 17:35:39', 0.00, 0, 'j', 'Главное меню', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041; 569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,47', 0, 0, 1),
(30, 1, 0, '2012-09-04 18:38:29', '2012-09-04 17:38:29', 0.00, 0, 'dddd', 'Главное меню', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 1),
(31, 1, 0, '2012-09-04 18:39:27', '2012-09-04 17:39:27', 80.00, 0, 'dddd', 'Главное меню', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 1),
(32, 1, 0, '2012-09-04 18:40:11', '2012-09-04 17:40:11', 80.00, 0, 'dddd', 'Главное меню', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 1),
(33, 1, 0, '2012-09-04 18:42:31', '2012-09-04 17:42:31', 400.00, 0, 'jhg', 'Главное меню', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 5),
(34, 1, 0, '2012-09-06 18:19:47', '2012-09-06 17:19:47', 270.00, 0, 'yyyyy', 'Юрий', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 0, 0, 2),
(35, 1, 0, '2012-09-06 18:20:57', '2012-09-06 17:28:57', 290.00, 0, 'yyyyy', 'Юрий', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 1, 1, 2),
(36, 1, 0, '2012-09-06 18:47:02', '2012-09-06 17:47:33', 270.00, 0, '', 'Главное меню', '54435345', 'www_alex@list.ru', '+38 &#040;097&#041; 569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', 1, 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `orders_product`
--

CREATE TABLE IF NOT EXISTS `orders_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `orders_id` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL,
  `price` float(12,2) DEFAULT NULL,
  `discount` int(11) NOT NULL,
  `amount` int(11) DEFAULT NULL,
  `sum` float(12,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_id` (`orders_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `orders_product`
--

INSERT INTO `orders_product` (`id`, `product_id`, `orders_id`, `name`, `price`, `discount`, `amount`, `sum`) VALUES
(12, 10, 17, 'SW B6', 450.00, 0, 3, 2700.00),
(13, 9, 17, 'SW B4', 540.00, 0, 3, 1620.00),
(14, 6, 17, 'brt-92fs', 220.00, 0, 1, 220.00),
(15, 10, 18, 'SW B6', NULL, 5, 2, 0.00),
(16, 10, 19, 'SW B6', 450.00, 5, 1, 450.00),
(17, 9, 19, 'SW B4', 540.00, 0, 1, 540.00),
(18, 9, 20, 'SW B4', 540.00, 0, 1, 540.00),
(19, 10, 20, 'SW B6', 450.00, 5, 1, 450.00),
(20, 9, 21, 'SW B4', 540.00, 0, 1, 540.00),
(21, 10, 21, 'SW B6', 427.50, 5, 1, 427.50),
(22, 9, 22, 'SW B4', 540.00, 0, 1, 540.00),
(23, 9, 23, 'SW B4', 540.00, 0, 1, 540.00),
(24, 10, 23, 'SW B6', 427.50, 5, 1, 427.50),
(25, 9, 24, 'SW B4', 540.00, 0, 1, 540.00),
(26, 10, 24, 'SW B6', 427.50, 5, 1, 427.50),
(27, 9, 25, 'SW B4', 540.00, 0, 1, 540.00),
(28, 10, 25, 'SW B6', 427.50, 5, 1, 427.50),
(29, 10, 26, 'SW B6', 427.50, 5, 1, 427.50),
(30, 9, 27, 'SW B4', 540.00, 0, 1, 540.00),
(31, 10, 27, 'SW B6', 427.50, 5, 1, 427.50),
(32, 10, 28, 'SW B6', 427.50, 5, 1, 427.50),
(33, 10, 29, 'Чикен Ранч', 0.00, 5, 1, 0.00),
(34, 14, 30, 'Четыре сыра', 0.00, 0, 1, 0.00),
(35, 14, 31, 'Четыре сыра', 80.00, 0, 1, 80.00),
(36, 14, 32, 'Четыре сыра', 80.00, 0, 1, 80.00),
(37, 14, 33, 'Четыре сыра', 80.00, 0, 5, 400.00),
(38, 14, 34, 'Четыре сыра', 80.00, 0, 2, 160.00),
(39, 14, 35, 'Четыре сыра', 90.00, 5, 2, 180.00),
(40, 14, 36, 'Четыре сыра', 80.00, 0, 2, 160.00);

-- --------------------------------------------------------

--
-- Table structure for table `orders_status`
--

CREATE TABLE IF NOT EXISTS `orders_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `orders_status`
--

INSERT INTO `orders_status` (`id`, `name`) VALUES
(1, 'Новый'),
(2, 'Обрабатывается'),
(3, 'Оплачен'),
(4, 'Отменен'),
(5, 'Закрыт');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  `form` enum('0','1','2') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `sort`, `active`, `url`, `form`) VALUES
(27, 0, '1', '/', '0'),
(39, 0, '1', 'otkritie-avto', '0'),
(41, 0, '1', 'otkritie-seyfov', '0'),
(42, 0, '1', 'izgotovlenie-klyuchey', '0'),
(43, 0, '1', 'zamena-i-ustanovka-zamkov', '0'),
(44, 0, '1', 'remont-i-servis-zamkov', '0'),
(45, 0, '1', 'discount', '2'),
(46, 0, '1', 'glavnoe-menyuk2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `params`
--

CREATE TABLE IF NOT EXISTS `params` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0' COMMENT '1-выводить/0-не выводить',
  `url` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='справочник: Свойства продукции' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `params`
--

INSERT INTO `params` (`id`, `sub`, `sort`, `active`, `url`) VALUES
(1, NULL, 0, '1', ''),
(2, NULL, 0, '1', ''),
(3, 1, 0, '1', ''),
(4, 1, 0, '1', ''),
(5, 2, 0, '1', ''),
(6, 2, 0, '1', '');

-- --------------------------------------------------------

--
-- Table structure for table `params_product`
--

CREATE TABLE IF NOT EXISTS `params_product` (
  `params_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  KEY `params_id` (`params_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='смежная таблица:Настройки характеристик для продукции';

--
-- Dumping data for table `params_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `name`, `active`, `sort`) VALUES
(1, 'Безналичный', '0', 0),
(2, 'Наличный', '0', 0),
(3, 'Кредитной картой', '0', 0),
(4, 'Банковский перевод', '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `photo`
--

CREATE TABLE IF NOT EXISTS `photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photos_id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `photos_id` (`photos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `photo`
--


-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sub` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `active` enum('0','1') DEFAULT '0',
  `url` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `photos`
--


-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brend_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `code` varchar(32) NOT NULL,
  `price` float(12,2) NOT NULL,
  `discount` int(11) NOT NULL,
  `cnt` int(11) DEFAULT NULL,
  `url` varchar(128) DEFAULT NULL,
  `active` enum('0','1') DEFAULT '0' COMMENT '1-ON / 0- OFF',
  `date_add` datetime DEFAULT '0000-00-00 00:00:00',
  `date_edit` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `brend_id`, `status_id`, `code`, `price`, `discount`, `cnt`, `url`, `active`, `date_add`, `date_edit`, `sort`) VALUES
(9, 0, 0, '436211Е', 70.00, 0, NULL, 'bavarskaya', '1', '2012-06-07 18:05:29', '2012-08-02 16:07:41', 0),
(10, 0, 0, 'B00006UK8Q', 65.00, 5, 0, 'chiken-ranch', '1', '2012-06-07 18:09:53', '2012-08-15 12:17:41', 0),
(14, 0, 0, 'B00005UK8Q', 80.00, 0, 1, 'chetire-sira', '1', '2012-07-05 14:58:55', '2012-08-03 15:06:24', 0),
(15, 0, 0, '', 0.00, 0, 1, 'glavnoe-menyu', '0', '2012-08-16 12:51:58', '2012-08-16 11:51:58', 0),
(16, 0, 0, '', 0.00, 0, 1, 'filtri-tovarov', '1', '2012-08-16 12:52:40', '2012-08-16 11:52:40', 0),
(17, 0, 0, '', 0.00, 0, 1, 'yuriy', '1', '2012-08-16 12:57:25', '2012-08-22 10:22:17', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_catalog`
--

CREATE TABLE IF NOT EXISTS `product_catalog` (
  `product_id` int(11) DEFAULT NULL,
  `catalog_id` int(11) DEFAULT NULL,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_catalog`
--

INSERT INTO `product_catalog` (`product_id`, `catalog_id`) VALUES
(10, 10),
(9, 10),
(14, 10);

-- --------------------------------------------------------

--
-- Table structure for table `product_photo`
--

CREATE TABLE IF NOT EXISTS `product_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `product_photo`
--

INSERT INTO `product_photo` (`id`, `product_id`, `active`, `sort`) VALUES
(4, 14, '1', 0),
(5, 14, '1', 0),
(6, 14, '1', 0),
(7, 14, '1', 0),
(8, 14, '1', 0),
(9, 9, '1', 0),
(10, 9, '1', 0),
(11, 9, '1', 0),
(12, 9, '1', 0),
(13, 17, '1', 0),
(14, 17, '1', 0),
(15, 17, '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_status`
--

CREATE TABLE IF NOT EXISTS `product_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(128) NOT NULL,
  `comment` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `product_status`
--

INSERT INTO `product_status` (`id`, `url`, `comment`) VALUES
(1, 'discount', 'Скидки'),
(2, 'hot-offers', 'Горячие предложения!');

-- --------------------------------------------------------

--
-- Table structure for table `product_status_set`
--

CREATE TABLE IF NOT EXISTS `product_status_set` (
  `product_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_status_set`
--

INSERT INTO `product_status_set` (`product_id`, `status_id`) VALUES
(10, 2),
(9, 2),
(14, 2);

-- --------------------------------------------------------

--
-- Table structure for table `ru_article`
--

CREATE TABLE IF NOT EXISTS `ru_article` (
  `article_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body_m` varchar(256) NOT NULL,
  `body` longtext,
  KEY `article_id` (`article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_article`
--

INSERT INTO `ru_article` (`article_id`, `name`, `title`, `keywords`, `description`, `body_m`, `body`) VALUES
(4, 'Главное меню', '', '', '', 'asdas', '&lt;p&gt;asdasd&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `ru_catalog`
--

CREATE TABLE IF NOT EXISTS `ru_catalog` (
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_catalog`
--

INSERT INTO `ru_catalog` (`cat_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(2, 'Литература', 'ф', 'фф', 'ввв', '&lt;p&gt;описени&lt;/p&gt;'),
(3, 'Услуги', 'в', 'ввввввввввв', 'ввввввввввввввв', '&lt;p&gt;ываыва&lt;/p&gt;'),
(9, 'Каталог товаров', '', '', '', ''),
(10, 'Игрушки', '', '', '', ''),
(11, 'Украшения', '', '', '', ''),
(12, 'Декор интерьера', '', '', '', ''),
(13, 'Упаковка', '', '', '', ''),
(15, 'Открытки', '', '', '', ''),
(16, 'Котэ', '', '', '', ''),
(17, 'Зайчики', '', '', '', ''),
(18, 'Мишки', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_info_blocks`
--

CREATE TABLE IF NOT EXISTS `ru_info_blocks` (
  `info_id` int(11) DEFAULT NULL COMMENT '��� �����',
  `name` varchar(64) DEFAULT NULL COMMENT '������������',
  `body` text,
  KEY `pages_id` (`info_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU: ���� ����� ';

--
-- Dumping data for table `ru_info_blocks`
--

INSERT INTO `ru_info_blocks` (`info_id`, `name`, `body`) VALUES
(1, 'Верхние контакты', '&lt;p&gt;&#040;066&#041; 314 15 23&lt;br /&gt; &#040;066&#041; 314 15 23&lt;/p&gt;'),
(3, 'Рекомендации', '&lt;h3&gt;Рекомендации&lt;/h3&gt;\r\n&lt;p&gt;Как правильно измерять артериальное давление&lt;br /&gt;Точность полученных результатов, гарантия правильной диагностики гипертонии зависят от соблюдения некоторых правил. Для определения артериального давления имеют значение положение пациента, сопутствующие обстоятельства, оснащение и владение техникой измерения.&lt;/p&gt;\r\n&lt;p&gt;Как правильно принимать таблетки&lt;br /&gt;Если таблетка имеет овальную форму и покрыта оболочкой, ее следует глотать не разжевывая &#040;это же относится к порошкам в капсулах&#041;. кардиограф Остальные таблетки и порошки перед приемом внутрь желательно измельчить и запить жидкостью.&lt;/p&gt;\r\n&lt;p&gt;Как правильно измерять артериальное давление&lt;br /&gt;Точность полученных результатов, гарантия правильной диагностики гипертонии зависят от соблюдения некоторых правил. Для определения артериального давления имеют значение положение пациента, сопутствующие обстоятельства, оснащение и владение техникой измерения.&lt;/p&gt;'),
(4, 'Бонус', '&lt;p&gt;&lt;a href=&quot;/discount&quot;&gt;&lt;img src=&quot;/files/storage/images/ban4.png&quot; alt=&quot;&quot; /&gt;&lt;/a&gt;&lt;/p&gt;'),
(5, 'Бренды', '&lt;p&gt;&nbsp;&lt;/p&gt;\r\n&lt;p&gt;&lt;strong&gt;Бренды&lt;/strong&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;img src=&quot;/files/storage/images/ban1.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt;&lt;img src=&quot;/files/storage/images/ban2.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;br /&gt;&lt;img src=&quot;/files/storage/images/ban3.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;'),
(6, 'Баннер на главной &#040;верхний&#041;', '&lt;p&gt;&lt;img src=&quot;/files/storage/ban.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;'),
(7, 'Баннер на главной &#040;нижний&#041;', '&lt;p&gt;&lt;img src=&quot;/files/storage/images/banner.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;');

-- --------------------------------------------------------

--
-- Table structure for table `ru_menu`
--

CREATE TABLE IF NOT EXISTS `ru_menu` (
  `menu_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `menu_id` (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_menu`
--

INSERT INTO `ru_menu` (`menu_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(64, 'Оплата доставка', '', '', '', '&lt;p&gt;1. Срочное открывание квартир.&lt;br /&gt;Вы потеряли ключи, захлопнулась дверь, а на плите кастрюля, заклинил замок, сломался ключ, или по иной причине Вы не можете попасть домой, - Наша фирма готова в кратчайшие сроки прибыть и устранить поломку.&lt;br /&gt;2. Срочное открывание автомобилей любых марок.&lt;br /&gt;Также наши мастера осуществляют вскрытие автомобилей любых марок без повреждений Вашего авто. Сопутствующий сервис:&lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Изготовление ключей по замку &#040;т.е. если был утерян ключ от автомобиля - возможно его изготовление по номерам пластин замка; эта услуга возможна и для изготовления ключей для замков крышек бака автомобиля&#041; &lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Изготовление чип ключа с возможностью перекодировки замка &lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Реставрация и восстановление работоспособности автомобильных замков после взлома &lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Ремонт замков и ключей, изменение секретности &#040;для автомобилей, домов, гаражей, сейфов&#041;&lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Профилактика замков: автомобильных, мотоциклетных, специальных, квартирных и сейфовых&lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Изготовление ключей любой сложности &#040;для автомобилей, квартир, гаражей, сейфов&#041; &lt;br /&gt;3. Открывание сейфов.&lt;br /&gt;Любая сложность. Открытие сейфов, оборудованных механическими шифраторами, электронными кодовыми, и ключевыми замками.&lt;br /&gt;4. Открывание гаражных замков.&lt;br /&gt;5. Открывание ролетных систем, металлопластиковых дверей.&lt;br /&gt;6. Изготовление ключей любой сложности.&lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Изготовление ключей любой сложности &#040;для автомобилей, квартир, гаражей, сейфов&#041; &lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Изготовление ключей по замку &#040;т.е. если был утерян ключ от автомобиля - возможно его изготовление по номерам пластин замка; эта услуга возможна и для изготовления ключей для замков крышек бака автомобиля&#041; &lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Изготовление чип ключа с возможностью перекодировки замка &lt;br /&gt;7. Установка, замена, ремонт замков.&lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Реставрация и восстановление работоспособности автомобильных замков после взлома &lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Замена замков, если замки не подлежат восстановлению &lt;br /&gt;&bull;&nbsp;&nbsp;&nbsp; Ремонт замков и ключей, изменение секретности &#040;для автомобилей, домов, гаражей, сейфов&#041;&lt;/p&gt;'),
(65, 'Услуги', '', '', '', '&lt;div class=&quot;title&quot;&gt;Немного о нас&lt;/div&gt;\r\n&lt;p&gt;Рекламное сообщество, все же пренебрегая деталями, редко соответствует рыночным ожиданиям. VIP-мероприятие, безусловно, уравновешивает бренд, осознав маркетинг как часть производства. В соответствии с законом Ципфа, опрос порождает межличностный формат события, оптимизируя бюджеты. Узнавание бренда отражает из ряда вон выходящий пресс-клиппинг, не считаясь с затратами. &lt;a href=&quot;/&quot;&gt;~ Узнать больше&lt;/a&gt;&lt;/p&gt;\r\n&lt;p&gt;&lt;img src=&quot;/files/storage/facebook.png&quot; alt=&quot;&quot; /&gt;&nbsp;&nbsp; &lt;img src=&quot;/files/storage/vk.png&quot; alt=&quot;&quot; /&gt;&nbsp;&nbsp; &lt;img src=&quot;/files/storage/twitter.png&quot; alt=&quot;&quot; /&gt;&lt;/p&gt;'),
(68, 'Контакты', '', '', '', '&lt;p&gt;asdasdasd&lt;/p&gt;'),
(71, 'Сотрудничество', '', '', '', ''),
(72, 'Литература', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_news`
--

CREATE TABLE IF NOT EXISTS `ru_news` (
  `news_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body_m` varchar(256) NOT NULL,
  `body` longtext,
  KEY `news_id` (`news_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_news`
--

INSERT INTO `ru_news` (`news_id`, `name`, `title`, `keywords`, `description`, `body_m`, `body`) VALUES
(4, 'Новостной заголовок 2', '', '', '', 'Создание одного приверженного покупателя все же амбивалентно. Привлечение всей же аудитории стабилизирует.', '&lt;p&gt;Тонометры - приборы которые измеряют давление крови в организме человека.&lt;/p&gt;'),
(5, 'Новостной заголовок', '', '', '', 'Создание одного приверженного покупателя все же амбивалентно. Привлечение всей же аудитории стабилизирует.', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_pages`
--

CREATE TABLE IF NOT EXISTS `ru_pages` (
  `pages_id` int(11) DEFAULT NULL,
  `name` varchar(64) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `body` longtext,
  KEY `pages_id` (`pages_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_pages`
--

INSERT INTO `ru_pages` (`pages_id`, `name`, `title`, `keywords`, `description`, `body`) VALUES
(27, 'Главная', '', '', '', ''),
(39, 'Открытие авто', '', '', '', 'кккк'),
(41, 'Открытие сейфов', '', '', '', ''),
(42, 'Изготовление ключей', '', '', '', ''),
(43, 'Замена и установка замков', '', '', '', ''),
(44, 'Ремонт и сервис замков', '', '', '', ''),
(45, 'Описание скидки', '', '', '', ''),
(46, 'Главное менюk', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_params`
--

CREATE TABLE IF NOT EXISTS `ru_params` (
  `params_id` int(11) DEFAULT NULL COMMENT 'Код группы категории',
  `name` varchar(64) DEFAULT NULL COMMENT 'Наименование категории номенклатуры',
  `info` text,
  KEY `params_id` (`params_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='TEXT RU справочник: Свойства продукции';

--
-- Dumping data for table `ru_params`
--

INSERT INTO `ru_params` (`params_id`, `name`, `info`) VALUES
(1, 'Мощность', NULL),
(2, 'Тип нагрева', NULL),
(3, '24кВт', NULL),
(4, '21-32кВт', NULL),
(5, 'отопление&#043;ГВС', NULL),
(6, 'отопление', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ru_photo`
--

CREATE TABLE IF NOT EXISTS `ru_photo` (
  `photo_id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`photo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_photo`
--


-- --------------------------------------------------------

--
-- Table structure for table `ru_photos`
--

CREATE TABLE IF NOT EXISTS `ru_photos` (
  `photos_id` int(11) DEFAULT NULL,
  `name` varchar(128) NOT NULL,
  `body_m` varchar(255) DEFAULT NULL,
  `body` text,
  `title` varchar(128) DEFAULT NULL,
  `keywords` text,
  `description` text,
  KEY `photos_id` (`photos_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_photos`
--


-- --------------------------------------------------------

--
-- Table structure for table `ru_product`
--

CREATE TABLE IF NOT EXISTS `ru_product` (
  `product_id` int(11) DEFAULT NULL,
  `name` varchar(256) NOT NULL,
  `body_m` longtext,
  `body` longtext,
  `title` varchar(128) DEFAULT NULL,
  `keywords` text,
  `description` text,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_product`
--

INSERT INTO `ru_product` (`product_id`, `name`, `body_m`, `body`, `title`, `keywords`, `description`) VALUES
(9, 'Баварская', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '&lt;p&gt;Глюкометр&nbsp; Контур ТС &#040;CONTOUR TS&#041; требует всего 0,6 мкл крови и позволяет получить точные результаты уже через 8 секунд. Существует возможность взятия проб крови из разных мест &mdash; кончика пальца, ладони или предплечья.&lt;/p&gt;', '', '', ''),
(10, 'Чикен Ранч', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '', '', ''),
(14, 'Четыре сыра', '&lt;p&gt;Сыры &quot;моцарелла&quot;, дор блю, голландский, пармезан, помидор, томатный пицца-соус, петрушка, орегано&lt;/p&gt;', '&lt;p&gt;asdasdasd&lt;/p&gt;', '', '', ''),
(15, 'Главное меню', '', '', '', '', ''),
(16, 'Фильтры товаров', '', '', '', '', ''),
(17, 'Юрий', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `ru_product_photo`
--

CREATE TABLE IF NOT EXISTS `ru_product_photo` (
  `photo_id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  KEY `photo_id` (`photo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_product_photo`
--

INSERT INTO `ru_product_photo` (`photo_id`, `name`) VALUES
(4, 'Aston_Martin_AMV10_sports_cars_wallpapers'),
(5, 'Lexus_LF-A_Sports,_Car_Concept,_2007'),
(6, 'sports car wallpaper-5'),
(7, 'Lexus_LF-A_Sports,_Car_Concept,_2007'),
(8, 'sports car wallpaper-5'),
(9, '153746_272837'),
(10, 'Aston_Martin_AMV10_sports_cars_wallpapers'),
(11, 'Lexus_LF-A_Sports,_Car_Concept,_2007'),
(12, 'sports car wallpaper-5'),
(13, 'sdf'),
(14, 'sdfsdf'),
(15, 'fffffffffff');

-- --------------------------------------------------------

--
-- Table structure for table `ru_translate`
--

CREATE TABLE IF NOT EXISTS `ru_translate` (
  `translate_id` int(11) NOT NULL AUTO_INCREMENT,
  `value` text,
  PRIMARY KEY (`translate_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='TEXT RU: ������� ��������' AUTO_INCREMENT=216 ;

--
-- Dumping data for table `ru_translate`
--

INSERT INTO `ru_translate` (`translate_id`, `value`) VALUES
(1, 'Создание сайта'),
(3, 'Все права защищены © 2012'),
(4, 'Новости'),
(7, 'Обратная связь'),
(8, 'ФИО'),
(9, 'Город'),
(10, 'Телефон'),
(11, 'поля обязательные для заполнения'),
(12, 'Отправить'),
(68, 'Вы искали'),
(70, 'Архив уроков'),
(72, 'Ничего не найдено'),
(82, 'Фамилия'),
(83, 'Имя'),
(84, 'Адрес'),
(85, 'Мобильный тел.'),
(86, 'Авторизация'),
(106, 'Поля * являются обязательными'),
(108, 'Поле Email: Неправильный email'),
(137, 'подробнее'),
(155, 'E-mail'),
(156, 'Сообщение'),
(157, 'Архив статей'),
(158, 'Все новости'),
(159, 'Последние новости'),
(165, 'Gletcher'),
(167, 'Последние комментарии'),
(168, 'Информационные материалы'),
(169, 'Задай вопрос'),
(170, 'Регистрация'),
(171, 'После проверки Ваш комментарий будет добавлен'),
(172, 'Видеоархив'),
(173, 'Отзывы'),
(174, 'Данные успешно сохранены'),
(175, 'Регистрация к этому руководителю'),
(176, 'Вы успешно зарегистрированы'),
(177, 'Неправильный код подтверждения'),
(178, 'Данный email зарегистрирован!'),
(179, 'Сообщение отправлено!'),
(180, 'Следующий'),
(181, 'Заказать'),
(182, 'Поиск'),
(183, 'Оформить заказ'),
(184, 'Описание'),
(185, 'Характеристики'),
(186, 'Меню'),
(187, 'Акции'),
(188, 'Все'),
(189, 'ТОП продаж'),
(190, 'Неверный формат телефона'),
(191, 'Вход'),
(193, 'Пароль'),
(194, 'E-mail не зарегистрирован'),
(195, 'Вы успешно авторизованы'),
(196, 'Сохранить'),
(197, 'Мои данные'),
(198, 'Мои заказы'),
(199, 'Новый пароль'),
(200, 'Старый пароль'),
(201, 'Почтовый индекс'),
(202, 'Корзина пуста'),
(203, 'Комментарии к заказу'),
(204, 'Выйти'),
(206, 'Новые поступления'),
(207, 'Популярные товары'),
(208, 'Рекомендуемые товары'),
(209, 'Главная'),
(210, 'E-mail добавлен в  базу!'),
(211, 'Подписка'),
(212, 'Подписаться'),
(213, 'Способ доставки'),
(214, 'Способ оплаты'),
(215, 'Горячие предложения');

-- --------------------------------------------------------

--
-- Table structure for table `ru_video`
--

CREATE TABLE IF NOT EXISTS `ru_video` (
  `video_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  KEY `video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ru_video`
--


-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(128) NOT NULL,
  `name` varchar(512) NOT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `url`, `name`, `active`, `sort`) VALUES
(8, '', 'BOSCH', '1', 1),
(9, '', 'База почтовых ящиков', '1', 2),
(10, '', '', '1', 0),
(11, '', '', '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `translate`
--

CREATE TABLE IF NOT EXISTS `translate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(128) DEFAULT NULL,
  `value_et` text,
  `comment` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='TEXT RU: ' AUTO_INCREMENT=216 ;

--
-- Dumping data for table `translate`
--

INSERT INTO `translate` (`id`, `key`, `value_et`, `comment`) VALUES
(1, 'skylogic', NULL, ''),
(3, 'copyright', NULL, 'Копирайт'),
(4, 'news', NULL, ''),
(7, 'feelback', NULL, ''),
(8, 'fio', NULL, ''),
(9, 'city', NULL, ''),
(10, 'phone', NULL, ''),
(11, 'fields', NULL, ''),
(12, 'send_message', NULL, ''),
(68, 'search', NULL, ''),
(70, 'arxiv_info', NULL, ''),
(72, 'not_found', NULL, ''),
(82, 'sname', NULL, ''),
(83, 'name', NULL, ''),
(84, 'address', NULL, ''),
(85, 'phone2', NULL, ''),
(86, 'auth', NULL, ''),
(106, 'required', NULL, ''),
(108, 'wrong_email', NULL, ''),
(137, 'read_more', NULL, ''),
(155, 'email', NULL, ''),
(156, 'message', NULL, ''),
(157, 'arxiv_news', NULL, ''),
(158, 'all_news', NULL, ''),
(159, 'last_news', NULL, ''),
(165, 'sitename', NULL, ''),
(167, 'last_comments', NULL, 'Последние комментарии'),
(168, 'info_block', NULL, 'Информационные материалы'),
(169, 'ask', NULL, 'Задай вопрос'),
(170, 'sign_up', NULL, 'Регистрация'),
(171, 'comment_add', NULL, 'После проверки Ваш комментарий будет добавлен'),
(172, 'video_name', NULL, 'Видеоархив'),
(173, 'comments', NULL, 'Отзывы'),
(174, 'save_data', NULL, 'Данные успешно сохранены'),
(175, 'user_reg', NULL, 'Регистрация к этому руководителю'),
(176, 'sign_up_yes', NULL, 'Вы успешно зарегистрированы'),
(177, 'wrong_code', NULL, 'Неправильный код подтверждения'),
(178, 'email_exists', NULL, 'Данный email зарегистрирован!'),
(179, 'message_sent', NULL, 'Сообщение отправлено!'),
(180, 'next', NULL, 'Следующий'),
(181, 'buy', NULL, 'Купить'),
(182, 'search_name', NULL, 'Поиск'),
(183, 'to_order', NULL, 'Оформить заказ'),
(184, 'desc', NULL, 'Описание'),
(185, 'param', NULL, 'Характеристики'),
(186, 'catalog', NULL, 'Каталог'),
(187, 'action', NULL, 'Акции'),
(188, 'all', NULL, 'Все'),
(189, 'top_product', NULL, 'ТОП продаж'),
(190, 'wrong_phone', NULL, ''),
(191, 'enter', NULL, 'Вход'),
(193, 'password', NULL, 'Пароль'),
(194, 'email_no_exists', NULL, 'E-mail не зарегистрирован'),
(195, 'auth_yes', NULL, 'Вы успешно авторизованы'),
(196, 'save', NULL, 'Сохранить'),
(197, 'my_data', NULL, 'Мои данные'),
(198, 'my_orders', NULL, 'Мои заказы'),
(199, 'new_pass', NULL, 'Новый пароль'),
(200, 'old_pass', NULL, 'Старый пароль'),
(201, 'post_index', NULL, 'Почтовый индекс'),
(202, 'cart_empty', NULL, 'Корзина пуста'),
(203, 'comments_order', NULL, 'Комментарии к заказу'),
(204, 'exit', NULL, 'Выйти'),
(206, 'novetly', NULL, 'Новые поступления'),
(207, 'top-sellers', NULL, 'Популярные товары'),
(208, 'recommend', NULL, 'Рекомендуемые товары'),
(209, 'main', NULL, 'Ссылка на главную в хленых крошках'),
(210, 'email_added', NULL, 'E-mail добавлен в  базу!'),
(211, 'mailer2', NULL, 'Подписка'),
(212, 'mailer', NULL, 'Подписаться'),
(213, 'delivery', NULL, 'Способ доставки'),
(214, 'payment', NULL, 'Способ оплаты'),
(215, 'hot_offers', NULL, 'Горячие предложения');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status_id` int(11) NOT NULL DEFAULT '0',
  `referral_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `surname` varchar(100) DEFAULT NULL,
  `patronymic` varchar(100) DEFAULT NULL,
  `pass` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `info` varchar(512) NOT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `skype` varchar(32) NOT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `post_index` varchar(100) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `discount` decimal(4,2) DEFAULT NULL,
  `active_email` int(11) DEFAULT NULL,
  `mailer` int(11) DEFAULT NULL,
  `active` enum('0','1') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status_id` (`status_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `status_id`, `referral_id`, `name`, `surname`, `patronymic`, `pass`, `email`, `info`, `phone`, `skype`, `city`, `address`, `post_index`, `start_date`, `discount`, `active_email`, `mailer`, `active`) VALUES
(16, 1, 0, 'Юрий', NULL, NULL, '438d54d0b9e7675cae51d1c85248b74c', 'thefactorial@gmail.com', '', '&#043;38 &#040;097&#041;569-83-92', '', 'Ильичевскw', 'ул. м Арнаутская,48', '54435345', '2012-07-06 15:37:08', NULL, 0, NULL, '0'),
(17, 1, 0, 'Новости сайта', NULL, NULL, 'd1ad5959a729f97b5c90588da7f8f14c', 'www_alex@list.ru', '', '&#043;38 &#040;097&#041;569-83-92', '', 'odessa', 'ул. м Арнаутская,48', '54435345', '2012-07-06 15:38:41', NULL, 2, NULL, '0'),
(18, 1, 0, 'Новости сайта', NULL, NULL, 'c182ed1c28a242521c825843c8027a07', 'alex.panomax@gmail.com', '', '&#043;38 &#040;097&#041;569-83-92', '', 'Одесса', 'ул. м Арнаутская,48', '54435345', '2012-07-06 15:41:05', NULL, 6, NULL, '0');

-- --------------------------------------------------------

--
-- Table structure for table `user_status`
--

CREATE TABLE IF NOT EXISTS `user_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `user_status`
--

INSERT INTO `user_status` (`id`, `comment`) VALUES
(1, 'Пользователь'),
(2, 'Менеджер');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE IF NOT EXISTS `video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` text NOT NULL,
  `active` enum('0','1') NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `video`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `moderators`
--
ALTER TABLE `moderators`
  ADD CONSTRAINT `moderators_ibfk_1` FOREIGN KEY (`type_moderator`) REFERENCES `moderators_type` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `orders_product`
--
ALTER TABLE `orders_product`
  ADD CONSTRAINT `orders_product_ibfk_1` FOREIGN KEY (`orders_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `params_product`
--
ALTER TABLE `params_product`
  ADD CONSTRAINT `params_product_ibfk_1` FOREIGN KEY (`params_id`) REFERENCES `params` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `params_product_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `photo`
--
ALTER TABLE `photo`
  ADD CONSTRAINT `photo_ibfk_1` FOREIGN KEY (`photos_id`) REFERENCES `photos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_catalog`
--
ALTER TABLE `product_catalog`
  ADD CONSTRAINT `product_catalog_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_photo`
--
ALTER TABLE `product_photo`
  ADD CONSTRAINT `product_photo_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_status_set`
--
ALTER TABLE `product_status_set`
  ADD CONSTRAINT `product_status_set_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_article`
--
ALTER TABLE `ru_article`
  ADD CONSTRAINT `ru_article_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `article` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_catalog`
--
ALTER TABLE `ru_catalog`
  ADD CONSTRAINT `ru_catalog_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_catalog_ibfk_2` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_catalog_ibfk_3` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ru_catalog_ibfk_4` FOREIGN KEY (`cat_id`) REFERENCES `catalog` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_info_blocks`
--
ALTER TABLE `ru_info_blocks`
  ADD CONSTRAINT `FK_ru_info_blocks_id` FOREIGN KEY (`info_id`) REFERENCES `info_blocks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_menu`
--
ALTER TABLE `ru_menu`
  ADD CONSTRAINT `ru_menu_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_news`
--
ALTER TABLE `ru_news`
  ADD CONSTRAINT `ru_news_ibfk_1` FOREIGN KEY (`news_id`) REFERENCES `news` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_pages`
--
ALTER TABLE `ru_pages`
  ADD CONSTRAINT `FK_ru_pages_id` FOREIGN KEY (`pages_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_params`
--
ALTER TABLE `ru_params`
  ADD CONSTRAINT `ru_params_ibfk_1` FOREIGN KEY (`params_id`) REFERENCES `params` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_photo`
--
ALTER TABLE `ru_photo`
  ADD CONSTRAINT `ru_photo_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `photo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_photos`
--
ALTER TABLE `ru_photos`
  ADD CONSTRAINT `ru_photos_ibfk_1` FOREIGN KEY (`photos_id`) REFERENCES `photos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_product`
--
ALTER TABLE `ru_product`
  ADD CONSTRAINT `ru_product_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_product_photo`
--
ALTER TABLE `ru_product_photo`
  ADD CONSTRAINT `ru_product_photo_ibfk_1` FOREIGN KEY (`photo_id`) REFERENCES `product_photo` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_translate`
--
ALTER TABLE `ru_translate`
  ADD CONSTRAINT `ru_translate_ibfk_1` FOREIGN KEY (`translate_id`) REFERENCES `translate` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ru_video`
--
ALTER TABLE `ru_video`
  ADD CONSTRAINT `ru_video_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `video` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`status_id`) REFERENCES `user_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
